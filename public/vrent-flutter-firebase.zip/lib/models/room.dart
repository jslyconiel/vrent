class SubUnit {
  final String id;
  final String unitNumber;
  final String unitType;
  final int price;
  final String status; // 'available' | 'occupied'
  final String? currentTenant;
  final List<String> features;

  const SubUnit({
    required this.id,
    required this.unitNumber,
    required this.unitType,
    required this.price,
    required this.status,
    this.currentTenant,
    required this.features,
  });

  SubUnit copyWith({
    String? status,
    String? currentTenant,
  }) {
    return SubUnit(
      id: id,
      unitNumber: unitNumber,
      unitType: unitType,
      price: price,
      status: status ?? this.status,
      currentTenant: currentTenant ?? this.currentTenant,
      features: features,
    );
  }

  factory SubUnit.fromMap(Map<String, dynamic> map) {
    return SubUnit(
      id: (map['id'] ?? '') as String,
      unitNumber: (map['unitNumber'] ?? '') as String,
      unitType: (map['unitType'] ?? 'Shared Room') as String,
      price: ((map['price'] ?? 2500) as num).toInt(),
      status: (map['status'] ?? 'available') as String,
      currentTenant: map['currentTenant'] as String?,
      features: List<String>.from(map['features'] ?? const []),
    );
  }

  Map<String, dynamic> toMap() => {
        'id': id,
        'unitNumber': unitNumber,
        'unitType': unitType,
        'price': price,
        'status': status,
        if (currentTenant != null) 'currentTenant': currentTenant,
        'features': features,
      };
}

class RoomMedia {
  final String type; // 'video' | 'panorama'
  final String url;
  final String? fileName;
  final String? caption;
  final String uploadedAt;

  const RoomMedia({
    required this.type,
    required this.url,
    this.fileName,
    this.caption,
    required this.uploadedAt,
  });

  factory RoomMedia.fromMap(Map<String, dynamic> map) {
    return RoomMedia(
      type: (map['type'] ?? 'panorama') as String,
      url: (map['url'] ?? '') as String,
      fileName: map['fileName'] as String?,
      caption: map['caption'] as String?,
      uploadedAt: (map['uploadedAt'] ?? '') as String,
    );
  }

  Map<String, dynamic> toMap() => {
        'type': type,
        'url': url,
        if (fileName != null) 'fileName': fileName,
        if (caption != null) 'caption': caption,
        'uploadedAt': uploadedAt,
      };
}

class Room {
  final String id;
  final String ownerId;
  final String title;
  final String type;
  final String location;
  final String city;
  final String barangay;
  final String? nearSchool;
  final String landmark;
  final double distanceKm;
  final int walkingMinutes;
  final String genderPolicy; // 'Mixed' | 'Female Only' | 'Male Only'
  final String utilitiesIncluded;
  final int price;
  final List<String> amenities;
  final List<String> tags;
  final int slotsAvailable;
  final int totalSlots;
  final String availableFrom;
  final String ownerName;
  final String ownerPhone;
  final bool ownerVerified;
  final String? ownerIdType;
  final String? ownerVerificationDocUrl;
  final String description;
  final List<String> rules;
  final double lat;
  final double lng;
  final List<SubUnit> subUnits;
  final RoomMedia? roomMedia;

  const Room({
    required this.id,
    required this.ownerId,
    required this.title,
    required this.type,
    required this.location,
    required this.city,
    required this.barangay,
    this.nearSchool,
    required this.landmark,
    required this.distanceKm,
    this.walkingMinutes = 3,
    this.genderPolicy = 'Mixed',
    this.utilitiesIncluded = 'Water Included, Electric Submetered',
    required this.price,
    required this.amenities,
    required this.tags,
    required this.slotsAvailable,
    required this.totalSlots,
    required this.availableFrom,
    required this.ownerName,
    required this.ownerPhone,
    required this.ownerVerified,
    this.ownerIdType,
    this.ownerVerificationDocUrl,
    required this.description,
    required this.rules,
    required this.lat,
    required this.lng,
    required this.subUnits,
    this.roomMedia,
  });

  Room copyWith({
    String? title,
    String? type,
    String? location,
    String? barangay,
    String? nearSchool,
    String? landmark,
    int? walkingMinutes,
    String? genderPolicy,
    String? utilitiesIncluded,
    int? price,
    List<String>? amenities,
    int? slotsAvailable,
    int? totalSlots,
    String? ownerIdType,
    String? ownerVerificationDocUrl,
    String? description,
    List<String>? rules,
    double? lat,
    double? lng,
    List<SubUnit>? subUnits,
    RoomMedia? roomMedia,
    bool clearRoomMedia = false,
  }) {
    return Room(
      id: id,
      ownerId: ownerId,
      title: title ?? this.title,
      type: type ?? this.type,
      location: location ?? this.location,
      city: city,
      barangay: barangay ?? this.barangay,
      nearSchool: nearSchool ?? this.nearSchool,
      landmark: landmark ?? this.landmark,
      distanceKm: distanceKm,
      walkingMinutes: walkingMinutes ?? this.walkingMinutes,
      genderPolicy: genderPolicy ?? this.genderPolicy,
      utilitiesIncluded: utilitiesIncluded ?? this.utilitiesIncluded,
      price: price ?? this.price,
      amenities: amenities ?? this.amenities,
      tags: tags,
      slotsAvailable: slotsAvailable ?? this.slotsAvailable,
      totalSlots: totalSlots ?? this.totalSlots,
      availableFrom: availableFrom,
      ownerName: ownerName,
      ownerPhone: ownerPhone,
      ownerVerified: ownerVerified,
      ownerIdType: ownerIdType ?? this.ownerIdType,
      ownerVerificationDocUrl: ownerVerificationDocUrl ?? this.ownerVerificationDocUrl,
      description: description ?? this.description,
      rules: rules ?? this.rules,
      lat: lat ?? this.lat,
      lng: lng ?? this.lng,
      subUnits: subUnits ?? this.subUnits,
      roomMedia: clearRoomMedia ? null : (roomMedia ?? this.roomMedia),
    );
  }

  factory Room.fromMap(String id, Map<String, dynamic> map) {
    return Room(
      id: id,
      ownerId: (map['ownerId'] ?? 'seed-owner') as String,
      title: (map['title'] ?? '') as String,
      type: (map['type'] ?? 'Shared Room') as String,
      location: (map['location'] ?? '') as String,
      city: (map['city'] ?? 'Oroquieta') as String,
      barangay: (map['barangay'] ?? 'Mobod') as String,
      nearSchool: map['nearSchool'] as String?,
      landmark: (map['landmark'] ?? '') as String,
      distanceKm: ((map['distanceKm'] ?? 0.3) as num).toDouble(),
      walkingMinutes: ((map['walkingMinutes'] ?? 3) as num).toInt(),
      genderPolicy: (map['genderPolicy'] ?? 'Mixed') as String,
      utilitiesIncluded: (map['utilitiesIncluded'] ?? 'Water Included, Electric Submetered') as String,
      price: ((map['price'] ?? 2500) as num).toInt(),
      amenities: List<String>.from(map['amenities'] ?? const []),
      tags: List<String>.from(map['tags'] ?? const []),
      slotsAvailable: ((map['slotsAvailable'] ?? 0) as num).toInt(),
      totalSlots: ((map['totalSlots'] ?? 1) as num).toInt(),
      availableFrom: (map['availableFrom'] ?? '2026-11-08') as String,
      ownerName: (map['ownerName'] ?? 'Verified Owner') as String,
      ownerPhone: (map['ownerPhone'] ?? '') as String,
      ownerVerified: (map['ownerVerified'] ?? true) as bool,
      ownerIdType: map['ownerIdType'] as String?,
      ownerVerificationDocUrl: map['ownerVerificationDocUrl'] as String?,
      description: (map['description'] ?? '') as String,
      rules: List<String>.from(map['rules'] ?? const []),
      lat: ((map['lat'] ?? 8.4895) as num).toDouble(),
      lng: ((map['lng'] ?? 123.8038) as num).toDouble(),
      subUnits: (map['subUnits'] as List<dynamic>? ?? [])
          .map((e) => SubUnit.fromMap(Map<String, dynamic>.from(e as Map)))
          .toList(),
      roomMedia: map['roomMedia'] != null
          ? RoomMedia.fromMap(Map<String, dynamic>.from(map['roomMedia'] as Map))
          : null,
    );
  }

  Map<String, dynamic> toMap() => {
        'ownerId': ownerId,
        'title': title,
        'type': type,
        'location': location,
        'city': city,
        'barangay': barangay,
        if (nearSchool != null) 'nearSchool': nearSchool,
        'landmark': landmark,
        'distanceKm': distanceKm,
        'walkingMinutes': walkingMinutes,
        'genderPolicy': genderPolicy,
        'utilitiesIncluded': utilitiesIncluded,
        'price': price,
        'amenities': amenities,
        'tags': tags,
        'slotsAvailable': slotsAvailable,
        'totalSlots': totalSlots,
        'availableFrom': availableFrom,
        'ownerName': ownerName,
        'ownerPhone': ownerPhone,
        'ownerVerified': ownerVerified,
        if (ownerIdType != null) 'ownerIdType': ownerIdType,
        if (ownerVerificationDocUrl != null) 'ownerVerificationDocUrl': ownerVerificationDocUrl,
        'description': description,
        'rules': rules,
        'lat': lat,
        'lng': lng,
        'subUnits': subUnits.map((e) => e.toMap()).toList(),
        if (roomMedia != null) 'roomMedia': roomMedia!.toMap(),
      };
}

class BookingRequest {
  final String id;
  final String roomId;
  final String ownerId;
  final String roomTitle;
  final String? unitNumber;
  final int roomPrice;
  final String renterId;
  final String renterName;
  final String renterEmail;
  final String renterPhone;
  final int? renterAge;
  final String? renterGender;
  final String? renterSchool;
  final String? studentIdPhotoUrl;
  final String moveInDate;
  final int durationMonths;
  final String notes;
  final String status; // 'pending' | 'approved' | 'declined'
  final String createdAt;

  const BookingRequest({
    required this.id,
    required this.roomId,
    required this.ownerId,
    required this.roomTitle,
    this.unitNumber,
    required this.roomPrice,
    required this.renterId,
    required this.renterName,
    required this.renterEmail,
    required this.renterPhone,
    this.renterAge,
    this.renterGender,
    this.renterSchool,
    this.studentIdPhotoUrl,
    required this.moveInDate,
    required this.durationMonths,
    required this.notes,
    required this.status,
    required this.createdAt,
  });

  factory BookingRequest.fromMap(String id, Map<String, dynamic> map) {
    return BookingRequest(
      id: id,
      roomId: (map['roomId'] ?? '') as String,
      ownerId: (map['ownerId'] ?? '') as String,
      roomTitle: (map['roomTitle'] ?? '') as String,
      unitNumber: map['unitNumber'] as String?,
      roomPrice: ((map['roomPrice'] ?? 0) as num).toInt(),
      renterId: (map['renterId'] ?? '') as String,
      renterName: (map['renterName'] ?? '') as String,
      renterEmail: (map['renterEmail'] ?? '') as String,
      renterPhone: (map['renterPhone'] ?? '') as String,
      renterAge: (map['renterAge'] as num?)?.toInt(),
      renterGender: map['renterGender'] as String?,
      renterSchool: map['renterSchool'] as String?,
      studentIdPhotoUrl: map['studentIdPhotoUrl'] as String?,
      moveInDate: (map['moveInDate'] ?? '') as String,
      durationMonths: ((map['durationMonths'] ?? 5) as num).toInt(),
      notes: (map['notes'] ?? '') as String,
      status: (map['status'] ?? 'pending') as String,
      createdAt: (map['createdAt'] ?? '') as String,
    );
  }

  Map<String, dynamic> toMap() => {
        'roomId': roomId,
        'ownerId': ownerId,
        'roomTitle': roomTitle,
        if (unitNumber != null) 'unitNumber': unitNumber,
        'roomPrice': roomPrice,
        'renterId': renterId,
        'renterName': renterName,
        'renterEmail': renterEmail,
        'renterPhone': renterPhone,
        if (renterAge != null) 'renterAge': renterAge,
        if (renterGender != null) 'renterGender': renterGender,
        if (renterSchool != null) 'renterSchool': renterSchool,
        if (studentIdPhotoUrl != null) 'studentIdPhotoUrl': studentIdPhotoUrl,
        'moveInDate': moveInDate,
        'durationMonths': durationMonths,
        'notes': notes,
        'status': status,
        'createdAt': createdAt,
      };
}

class PaymentRecord {
  final String id;
  final String requestId;
  final String roomId;
  final String? ownerId;
  final String roomTitle;
  final String? unitNumber;
  final String renterId;
  final String renterName;
  final int amount;
  final String monthCovered;
  final String paidDate;
  final String method;
  final String referenceNo;
  final String? receiptImageUrl;
  final String status;

  const PaymentRecord({
    required this.id,
    required this.requestId,
    required this.roomId,
    this.ownerId,
    required this.roomTitle,
    this.unitNumber,
    required this.renterId,
    required this.renterName,
    required this.amount,
    required this.monthCovered,
    required this.paidDate,
    required this.method,
    required this.referenceNo,
    this.receiptImageUrl,
    required this.status,
  });

  factory PaymentRecord.fromMap(String id, Map<String, dynamic> map) {
    return PaymentRecord(
      id: id,
      requestId: (map['requestId'] ?? '') as String,
      roomId: (map['roomId'] ?? '') as String,
      ownerId: map['ownerId'] as String?,
      roomTitle: (map['roomTitle'] ?? '') as String,
      unitNumber: map['unitNumber'] as String?,
      renterId: (map['renterId'] ?? '') as String,
      renterName: (map['renterName'] ?? '') as String,
      amount: ((map['amount'] ?? 0) as num).toInt(),
      monthCovered: (map['monthCovered'] ?? '') as String,
      paidDate: (map['paidDate'] ?? '') as String,
      method: (map['method'] ?? 'GCash') as String,
      referenceNo: (map['referenceNo'] ?? '') as String,
      receiptImageUrl: map['receiptImageUrl'] as String?,
      status: (map['status'] ?? 'pending') as String,
    );
  }

  Map<String, dynamic> toMap() => {
        'requestId': requestId,
        'roomId': roomId,
        if (ownerId != null) 'ownerId': ownerId,
        'roomTitle': roomTitle,
        if (unitNumber != null) 'unitNumber': unitNumber,
        'renterId': renterId,
        'renterName': renterName,
        'amount': amount,
        'monthCovered': monthCovered,
        'paidDate': paidDate,
        'method': method,
        'referenceNo': referenceNo,
        if (receiptImageUrl != null) 'receiptImageUrl': receiptImageUrl,
        'status': status,
      };
}

class OwnerAnnouncement {
  final String id;
  final String? ownerId;
  final String title;
  final String message;
  final String date;
  final String priority;
  final String author;

  const OwnerAnnouncement({
    required this.id,
    this.ownerId,
    required this.title,
    required this.message,
    required this.date,
    this.priority = 'important',
    required this.author,
  });

  factory OwnerAnnouncement.fromMap(String id, Map<String, dynamic> map) {
    return OwnerAnnouncement(
      id: id,
      ownerId: map['ownerId'] as String?,
      title: (map['title'] ?? '') as String,
      message: (map['message'] ?? '') as String,
      date: (map['date'] ?? '') as String,
      priority: (map['priority'] ?? 'important') as String,
      author: (map['author'] ?? '') as String,
    );
  }

  Map<String, dynamic> toMap() => {
        if (ownerId != null) 'ownerId': ownerId,
        'title': title,
        'message': message,
        'date': date,
        'priority': priority,
        'author': author,
      };
}

class ChatMessage {
  final String id;
  final String senderId;
  final String senderName;
  final String senderRole;
  final String text;
  final String createdAt;

  const ChatMessage({
    required this.id,
    required this.senderId,
    required this.senderName,
    required this.senderRole,
    required this.text,
    required this.createdAt,
  });

  factory ChatMessage.fromMap(String id, Map<String, dynamic> map) {
    return ChatMessage(
      id: id,
      senderId: (map['senderId'] ?? '') as String,
      senderName: (map['senderName'] ?? '') as String,
      senderRole: (map['senderRole'] ?? 'renter') as String,
      text: (map['text'] ?? '') as String,
      createdAt: (map['createdAt'] ?? '') as String,
    );
  }

  Map<String, dynamic> toMap() => {
        'senderId': senderId,
        'senderName': senderName,
        'senderRole': senderRole,
        'text': text,
        'createdAt': createdAt,
      };
}

class AppUser {
  final String uid;
  final String name;
  final String email;
  final String role; // 'renter' | 'owner'
  final int? age;
  final String? gender;
  final String? school;
  final String? studentIdPhotoUrl;
  final String? ownerIdType;
  final String? ownerVerificationDocUrl;

  const AppUser({
    required this.uid,
    required this.name,
    required this.email,
    required this.role,
    this.age,
    this.gender,
    this.school,
    this.studentIdPhotoUrl,
    this.ownerIdType,
    this.ownerVerificationDocUrl,
  });

  AppUser copyWith({
    String? name,
    int? age,
    String? gender,
    String? school,
    String? studentIdPhotoUrl,
    String? ownerIdType,
    String? ownerVerificationDocUrl,
  }) {
    return AppUser(
      uid: uid,
      name: name ?? this.name,
      email: email,
      role: role,
      age: age ?? this.age,
      gender: gender ?? this.gender,
      school: school ?? this.school,
      studentIdPhotoUrl: studentIdPhotoUrl ?? this.studentIdPhotoUrl,
      ownerIdType: ownerIdType ?? this.ownerIdType,
      ownerVerificationDocUrl: ownerVerificationDocUrl ?? this.ownerVerificationDocUrl,
    );
  }
}
