import 'package:flutter/material.dart';
import '../models/room.dart';

class UnitsDirectorySheet extends StatelessWidget {
  final Room room;
  final void Function(SubUnit unit) onSelectUnitToBook;

  const UnitsDirectorySheet({
    super.key,
    required this.room,
    required this.onSelectUnitToBook,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '${room.title} — All Rooms / Bedspaces',
            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 12),
          if (room.subUnits.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 20),
              child: Text('No individual sub-units configured yet.'),
            )
          else
            ...room.subUnits.map((u) {
              final avail = u.status == 'available';
              return Card(
                child: ListTile(
                  title: Text(u.unitNumber, style: const TextStyle(fontWeight: FontWeight.w700)),
                  subtitle: Text('₱${u.price}/mo · ${u.features.join(", ")}'),
                  trailing: avail
                      ? ElevatedButton(
                          onPressed: () => onSelectUnitToBook(u),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFFE05D26),
                            foregroundColor: Colors.white,
                          ),
                          child: const Text('Select'),
                        )
                      : Chip(label: Text(u.status.toUpperCase())),
                ),
              );
            }),
        ],
      ),
    );
  }
}
