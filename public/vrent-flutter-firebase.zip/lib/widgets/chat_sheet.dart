import 'package:flutter/material.dart';
import '../models/room.dart';
import '../services/firebase_service.dart';

class ChatSheet extends StatefulWidget {
  final Room room;
  final FirebaseService firebaseService;
  final AppUser? currentUser;

  const ChatSheet({
    super.key,
    required this.room,
    required this.firebaseService,
    required this.currentUser,
  });

  @override
  State<ChatSheet> createState() => _ChatSheetState();
}

class _ChatSheetState extends State<ChatSheet> {
  final _msgCtrl = TextEditingController();

  Future<void> _send() async {
    final text = _msgCtrl.text.trim();
    if (text.isEmpty || widget.currentUser == null) return;
    _msgCtrl.clear();
    await widget.firebaseService.sendChatMessage(
      widget.room.id,
      ChatMessage(
        id: '',
        senderId: widget.currentUser!.uid,
        senderName: widget.currentUser!.name,
        senderRole: widget.currentUser!.role,
        text: text,
        createdAt: DateTime.now().toIso8601String(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: MediaQuery.of(context).size.height * 0.72,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text(
              'Chat with ${widget.room.ownerName}',
              style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800),
            ),
          ),
          const Divider(height: 1),
          Expanded(
            child: StreamBuilder<List<ChatMessage>>(
              stream: widget.firebaseService.watchRoomChat(widget.room.id),
              builder: (context, snapshot) {
                final messages = snapshot.data ?? [];
                if (messages.isEmpty) {
                  return const Center(child: Text('Start asking about the boarding room!'));
                }
                return ListView.builder(
                  padding: const EdgeInsets.all(14),
                  itemCount: messages.length,
                  itemBuilder: (_, i) {
                    final m = messages[i];
                    final isMe = m.senderId == widget.currentUser?.uid;
                    return Align(
                      alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 8),
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                        decoration: BoxDecoration(
                          color: isMe ? const Color(0xFFE05D26) : const Color(0xFFE7E5E4),
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: Text(
                          '${m.senderName}: ${m.text}',
                          style: TextStyle(color: isMe ? Colors.white : Colors.black87, fontSize: 15),
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
          Padding(
            padding: EdgeInsets.fromLTRB(12, 8, 12, MediaQuery.of(context).viewInsets.bottom + 12),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _msgCtrl,
                    decoration: const InputDecoration(
                      hintText: 'Write a message...',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton.filled(
                  onPressed: _send,
                  icon: const Icon(Icons.send),
                  style: IconButton.styleFrom(backgroundColor: const Color(0xFFE05D26)),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
