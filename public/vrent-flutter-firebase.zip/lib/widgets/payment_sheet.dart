import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../models/room.dart';
import '../services/firebase_service.dart';

class PaymentSheet extends StatefulWidget {
  final Room room;
  final FirebaseService firebaseService;
  final AppUser? currentUser;

  const PaymentSheet({
    super.key,
    required this.room,
    required this.firebaseService,
    required this.currentUser,
  });

  @override
  State<PaymentSheet> createState() => _PaymentSheetState();
}

class _PaymentSheetState extends State<PaymentSheet> {
  final _refCtrl = TextEditingController();
  final _monthCtrl = TextEditingController(text: 'November 2026 (Advance Deposit)');
  late final TextEditingController _amountCtrl;
  String _method = 'GCash';
  XFile? _receiptFile;
  bool _submitting = false;

  @override
  void initState() {
    super.initState();
    _amountCtrl = TextEditingController(text: widget.room.price.toString());
  }

  Future<void> _pickReceipt() async {
    final picker = ImagePicker();
    final file = await picker.pickImage(source: ImageSource.gallery, imageQuality: 80);
    if (file != null) setState(() => _receiptFile = file);
  }

  Future<void> _submitPayment() async {
    if (widget.currentUser == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please sign in first to submit a payment receipt.')),
      );
      return;
    }
    setState(() => _submitting = true);
    try {
      String? receiptUrl;
      if (_receiptFile != null) {
        final bytes = await widget.firebaseService.readFileBytes(_receiptFile!.path);
        receiptUrl = await widget.firebaseService.uploadImageBytes(
          folder: 'payment_receipts',
          bytes: bytes,
          fileName: _receiptFile!.name,
        );
      }
      final payment = PaymentRecord(
        id: '',
        requestId: 'direct-${DateTime.now().millisecondsSinceEpoch}',
        roomId: widget.room.id,
        ownerId: widget.room.ownerId,
        roomTitle: widget.room.title,
        renterId: widget.currentUser!.uid,
        renterName: widget.currentUser!.name,
        amount: int.tryParse(_amountCtrl.text) ?? widget.room.price,
        monthCovered: _monthCtrl.text.trim(),
        paidDate: DateTime.now().toIso8601String().split('T').first,
        method: _method,
        referenceNo: _refCtrl.text.trim(),
        receiptImageUrl: receiptUrl,
        status: 'pending',
      );
      await widget.firebaseService.submitPayment(payment);
      if (mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Receipt submitted! Pending owner verification.')),
        );
      }
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 20,
        bottom: MediaQuery.of(context).viewInsets.bottom + 20,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'GCash / Bank Receipt — ${widget.room.title}',
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: _method,
              decoration: const InputDecoration(labelText: 'Payment Method', border: OutlineInputBorder()),
              items: const [
                DropdownMenuItem(value: 'GCash', child: Text('GCash')),
                DropdownMenuItem(value: 'Bank Transfer', child: Text('Bank Transfer')),
                DropdownMenuItem(value: 'Cash', child: Text('Cash')),
              ],
              onChanged: (v) => setState(() => _method = v ?? 'GCash'),
            ),
            const SizedBox(height: 10),
            TextField(controller: _amountCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Amount (₱)', border: OutlineInputBorder())),
            const SizedBox(height: 10),
            TextField(controller: _monthCtrl, decoration: const InputDecoration(labelText: 'Month Covered', border: OutlineInputBorder())),
            const SizedBox(height: 10),
            TextField(controller: _refCtrl, decoration: const InputDecoration(labelText: 'Reference Number', border: OutlineInputBorder())),
            const SizedBox(height: 10),
            OutlinedButton.icon(
              onPressed: _pickReceipt,
              icon: const Icon(Icons.upload_file),
              label: Text(
                _receiptFile != null
                    ? 'Attached Receipt: ${_receiptFile!.name}'
                    : 'Upload GCash / Bank Receipt Screenshot',
              ),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _submitting ? null : _submitPayment,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFE05D26),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 15),
              ),
              child: _submitting
                  ? const CircularProgressIndicator(color: Colors.white)
                  : const Text('Submit Receipt for Verification', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
    );
  }
}
