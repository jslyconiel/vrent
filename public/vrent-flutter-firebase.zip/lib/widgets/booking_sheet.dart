import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../models/room.dart';
import '../services/firebase_service.dart';

class BookingSheet extends StatefulWidget {
  final Room room;
  final String? initialUnitNumber;
  final FirebaseService firebaseService;
  final AppUser? currentUser;

  const BookingSheet({
    super.key,
    required this.room,
    this.initialUnitNumber,
    required this.firebaseService,
    required this.currentUser,
  });

  @override
  State<BookingSheet> createState() => _BookingSheetState();
}

class _BookingSheetState extends State<BookingSheet> {
  late final TextEditingController _nameCtrl;
  late final TextEditingController _emailCtrl;
  final _phoneCtrl = TextEditingController();
  final _notesCtrl = TextEditingController();
  int _months = 5;
  bool _submitting = false;
  XFile? _studentIdFile;

  @override
  void initState() {
    super.initState();
    _nameCtrl = TextEditingController(text: widget.currentUser?.name ?? '');
    _emailCtrl = TextEditingController(text: widget.currentUser?.email ?? '');
  }

  Future<void> _pickStudentId() async {
    final picker = ImagePicker();
    final file = await picker.pickImage(source: ImageSource.gallery, imageQuality: 80);
    if (file != null) {
      setState(() => _studentIdFile = file);
    }
  }

  Future<void> _submit() async {
    if (widget.currentUser == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please sign in as a Renter first to send a booking request.')),
      );
      return;
    }

    setState(() => _submitting = true);
    String? idPhotoUrl = widget.currentUser?.studentIdPhotoUrl;
    try {
      if (_studentIdFile != null) {
        final bytes = await widget.firebaseService.readFileBytes(_studentIdFile!.path);
        idPhotoUrl = await widget.firebaseService.uploadImageBytes(
          folder: 'student_ids',
          bytes: bytes,
          fileName: _studentIdFile!.name,
        );
      }

      final req = BookingRequest(
        id: '',
        roomId: widget.room.id,
        ownerId: widget.room.ownerId,
        roomTitle: widget.room.title,
        unitNumber: widget.initialUnitNumber,
        roomPrice: widget.room.price,
        renterId: widget.currentUser!.uid,
        renterName: _nameCtrl.text.trim(),
        renterEmail: _emailCtrl.text.trim(),
        renterPhone: _phoneCtrl.text.trim(),
        renterAge: widget.currentUser?.age,
        renterGender: widget.currentUser?.gender,
        renterSchool: widget.currentUser?.school,
        studentIdPhotoUrl: idPhotoUrl,
        moveInDate: DateTime.now().add(const Duration(days: 7)).toIso8601String().split('T').first,
        durationMonths: _months,
        notes: _notesCtrl.text.trim(),
        status: 'pending',
        createdAt: DateTime.now().toIso8601String(),
      );

      await widget.firebaseService.submitBookingRequest(req);
      if (mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Booking request sent to owner!')),
        );
      }
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 20,
        bottom: MediaQuery.of(context).viewInsets.bottom + 20,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'Request ${widget.room.title}',
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
            ),
            if (widget.initialUnitNumber != null)
              Text('Selected Unit: ${widget.initialUnitNumber}', style: const TextStyle(color: Color(0xFFE05D26))),
            const SizedBox(height: 14),
            TextField(controller: _nameCtrl, decoration: const InputDecoration(labelText: 'Full Name', border: OutlineInputBorder())),
            const SizedBox(height: 10),
            TextField(controller: _emailCtrl, decoration: const InputDecoration(labelText: 'Email', border: OutlineInputBorder())),
            const SizedBox(height: 10),
            TextField(controller: _phoneCtrl, decoration: const InputDecoration(labelText: 'Mobile Number (+63...)', border: OutlineInputBorder())),
            const SizedBox(height: 10),
            DropdownButtonFormField<int>(
              value: _months,
              decoration: const InputDecoration(labelText: 'Duration', border: OutlineInputBorder()),
              items: const [
                DropdownMenuItem(value: 1, child: Text('1 month')),
                DropdownMenuItem(value: 5, child: Text('5 months (1 semester)')),
                DropdownMenuItem(value: 10, child: Text('10 months (Academic year)')),
              ],
              onChanged: (v) => setState(() => _months = v ?? 5),
            ),
            const SizedBox(height: 10),
            OutlinedButton.icon(
              onPressed: _pickStudentId,
              icon: const Icon(Icons.badge),
              label: Text(
                _studentIdFile != null
                    ? 'Attached ID: ${_studentIdFile!.name}'
                    : (widget.currentUser?.studentIdPhotoUrl != null ? 'Verified Student ID / COR Attached ✓' : 'Attach School ID / COR Photo (Optional)'),
              ),
            ),
            const SizedBox(height: 10),
            TextField(controller: _notesCtrl, maxLines: 2, decoration: const InputDecoration(labelText: 'Notes for Landlord', border: OutlineInputBorder())),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _submitting ? null : _submit,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFE05D26),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 16),
              ),
              child: _submitting
                  ? const CircularProgressIndicator(color: Colors.white)
                  : const Text('Submit Request', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
    );
  }
}
