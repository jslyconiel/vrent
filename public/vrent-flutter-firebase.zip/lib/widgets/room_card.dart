import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/room.dart';

class RoomCard extends StatelessWidget {
  final Room room;
  final VoidCallback onOpenTour;
  final VoidCallback onOpenUnits;
  final VoidCallback onOpenChat;
  final VoidCallback onOpenPayment;
  final VoidCallback onBook;

  const RoomCard({
    super.key,
    required this.room,
    required this.onOpenTour,
    required this.onOpenUnits,
    required this.onOpenChat,
    required this.onOpenPayment,
    required this.onBook,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.white,
      margin: const EdgeInsets.only(bottom: 16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Chip(label: Text(room.type, style: const TextStyle(fontSize: 13))),
                ElevatedButton.icon(
                  onPressed: onOpenTour,
                  icon: Icon(room.roomMedia?.type == 'video' ? Icons.videocam : Icons.threesixty),
                  label: Text(
                    room.roomMedia?.type == 'video'
                        ? 'Video & 360°'
                        : (room.roomMedia?.type == 'panorama' ? 'Owner 360°' : 'Room Tour'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Text(
              room.title,
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 4),
            Text(
              '${room.location} · ${room.walkingMinutes} mins walk',
              style: const TextStyle(fontSize: 15, color: Colors.black54),
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.indigo.shade50,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    room.genderPolicy,
                    style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: Colors.indigo.shade900),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.green.shade50,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    room.utilitiesIncluded,
                    style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: Colors.green.shade900),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '${room.slotsAvailable} free / ${room.totalSlots} total slots',
                  style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: Color(0xFF047857)),
                ),
                TextButton(
                  onPressed: onOpenUnits,
                  child: const Text('See All Rooms', style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
                ),
              ],
            ),
            const Divider(height: 22),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '₱${room.price}/mo',
                  style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900),
                ),
                Wrap(
                  spacing: 4,
                  children: [
                    IconButton(
                      onPressed: () async {
                        final uri = Uri.parse('https://www.google.com/maps/dir/?api=1&destination=${room.lat},${room.lng}');
                        await launchUrl(uri, mode: LaunchMode.externalApplication);
                      },
                      icon: const Icon(Icons.directions, color: Colors.green),
                      tooltip: 'Directions',
                    ),
                    IconButton(
                      onPressed: onOpenChat,
                      icon: const Icon(Icons.chat_bubble_outline, color: Color(0xFFE05D26)),
                      tooltip: 'Message Owner',
                    ),
                    IconButton(
                      onPressed: onOpenPayment,
                      icon: const Icon(Icons.receipt_long, color: Colors.amber),
                      tooltip: 'GCash Receipt & Notices',
                    ),
                    ElevatedButton(
                      onPressed: onBook,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFE05D26),
                        foregroundColor: Colors.white,
                      ),
                      child: const Text('Request', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
