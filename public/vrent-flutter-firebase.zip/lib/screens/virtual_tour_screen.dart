import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import '../models/room.dart';

class VirtualTourScreen extends StatefulWidget {
  final Room room;

  const VirtualTourScreen({super.key, required this.room});

  @override
  State<VirtualTourScreen> createState() => _VirtualTourScreenState();
}

class _VirtualTourScreenState extends State<VirtualTourScreen> {
  VideoPlayerController? _videoCtrl;
  double _panOffset = 0.0;

  @override
  void initState() {
    super.initState();
    final media = widget.room.roomMedia;
    if (media != null && media.type == 'video' && media.url.isNotEmpty) {
      _videoCtrl = VideoPlayerController.networkUrl(Uri.parse(media.url))
        ..initialize().then((_) {
          if (mounted) {
            setState(() {});
            _videoCtrl?.play();
          }
        });
    }
  }

  @override
  void dispose() {
    _videoCtrl?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final media = widget.room.roomMedia;
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: const Color(0xFF0E1615),
        foregroundColor: Colors.white,
        title: Text('${widget.room.title} · Room Tour'),
      ),
      body: Column(
        children: [
          Expanded(
            child: media == null
                ? const Center(
                    child: Padding(
                      padding: EdgeInsets.all(24),
                      child: Text(
                        'No owner video or panorama uploaded yet. Ask the owner to attach a room walkthrough video or 360° photo.',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.white70, fontSize: 17),
                      ),
                    ),
                  )
                : media.type == 'video'
                    ? _buildVideoPlayer()
                    : _buildPanoramaViewer(media.url),
          ),
          Container(
            color: const Color(0xFF141F1E),
            padding: const EdgeInsets.all(16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '₱${widget.room.price}/mo',
                      style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w800),
                    ),
                    Text(
                      '${widget.room.slotsAvailable} of ${widget.room.totalSlots} slots free',
                      style: const TextStyle(color: Color(0xFFFDE68A), fontSize: 15),
                    ),
                  ],
                ),
                Text(
                  media?.caption ?? widget.room.ownerName,
                  style: const TextStyle(color: Colors.white70, fontSize: 14),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildVideoPlayer() {
    if (_videoCtrl == null || !_videoCtrl!.value.isInitialized) {
      return const Center(child: CircularProgressIndicator(color: Color(0xFFE05D26)));
    }
    return Stack(
      alignment: Alignment.center,
      children: [
        AspectRatio(
          aspectRatio: _videoCtrl!.value.aspectRatio,
          child: VideoPlayer(_videoCtrl!),
        ),
        IconButton(
          iconSize: 64,
          color: Colors.white.withValues(alpha: 0.85),
          icon: Icon(_videoCtrl!.value.isPlaying ? Icons.pause_circle : Icons.play_circle),
          onPressed: () {
            setState(() {
              _videoCtrl!.value.isPlaying ? _videoCtrl!.pause() : _videoCtrl!.play();
            });
          },
        ),
      ],
    );
  }

  Widget _buildPanoramaViewer(String url) {
    return GestureDetector(
      onHorizontalDragUpdate: (details) {
        setState(() {
          _panOffset = (_panOffset + details.delta.dx * 0.003).clamp(-1.0, 1.0);
        });
      },
      child: Stack(
        fit: StackFit.expand,
        children: [
          InteractiveViewer(
            maxScale: 3.0,
            child: Image.network(
              url,
              fit: BoxFit.cover,
              alignment: Alignment(_panOffset, 0),
              errorBuilder: (_, __, ___) => const Center(
                child: Text('Unable to load panorama URL', style: TextStyle(color: Colors.white70)),
              ),
            ),
          ),
          Positioned(
            bottom: 16,
            left: 0,
            right: 0,
            child: Center(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  color: Colors.black87,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Text(
                  'Drag horizontally & pinch to inspect 360° panorama',
                  style: TextStyle(color: Colors.white, fontSize: 14),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
