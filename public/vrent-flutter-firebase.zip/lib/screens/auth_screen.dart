import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import '../data/oroquieta_schools.dart';
import '../models/room.dart';
import '../services/firebase_service.dart';

const List<String> philippineValidIds = [
  'Philippine Identification System (PhilSys) ID (PVC card, ePhilID, or Digital National ID via eGovPH app)',
  "Driver's License (issued by the LTO)",
  'Philippine Passport',
  'Unified Multi-Purpose ID (UMID) / SSS Card',
  "Voter's ID / COMELEC Registration Form",
  'Senior Citizen ID / Digital National Senior Citizens ID',
];

class AuthScreen extends StatefulWidget {
  final FirebaseService firebaseService;
  final String initialRole; // 'renter' | 'owner'
  final void Function(AppUser user) onAuthenticated;

  const AuthScreen({
    super.key,
    required this.firebaseService,
    required this.initialRole,
    required this.onAuthenticated,
  });

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  late String _role;
  bool _isSignUp = false;
  bool _isLoading = false;
  String? _error;

  final _emailCtrl = TextEditingController();
  final _passwordCtrl = TextEditingController();
  final _nameCtrl = TextEditingController();
  final _ageCtrl = TextEditingController(text: '19');
  String _gender = 'Female';
  String _selectedSchool = oroquietaCitySchools.first.name;
  XFile? _pickedStudentIdFile;

  XFile? _pickedOwnerIdFile;
  String _idType = philippineValidIds.first;

  @override
  void initState() {
    super.initState();
    _role = widget.initialRole;
  }

  Future<void> _pickOwnerValidIdDoc() async {
    final picker = ImagePicker();
    final file = await picker.pickImage(source: ImageSource.gallery, imageQuality: 80);
    if (file != null) {
      setState(() {
        _pickedOwnerIdFile = file;
        _error = null;
      });
    }
  }

  Future<void> _pickStudentIdDoc() async {
    final picker = ImagePicker();
    final file = await picker.pickImage(source: ImageSource.gallery, imageQuality: 80);
    if (file != null) {
      setState(() {
        _pickedStudentIdFile = file;
        _error = null;
      });
    }
  }

  Future<void> _submitCredentials() async {
    if (_emailCtrl.text.trim().isEmpty || _passwordCtrl.text.length < 6) {
      setState(() => _error = 'Enter a valid email and at least 6 characters password.');
      return;
    }

    int? parsedAge;
    if (_isSignUp) {
      if (_nameCtrl.text.trim().isEmpty) {
        setState(() => _error = 'Please enter your full name.');
        return;
      }
      parsedAge = int.tryParse(_ageCtrl.text.trim());
      final minAge = _role == 'owner' ? 18 : 14;
      if (parsedAge == null || parsedAge < minAge || parsedAge > 100) {
        setState(() => _error = 'Please enter a valid age ($minAge - 100).');
        return;
      }
      if (_role == 'renter') {
        if (_selectedSchool.isEmpty) {
          setState(() => _error = 'Please select your school in Oroquieta City.');
          return;
        }
        if (_pickedStudentIdFile == null) {
          setState(() => _error = 'Please upload your School ID, Valid ID, or Certificate of Enrollment (COR).');
          return;
        }
      }
      if (_role == 'owner' && _pickedOwnerIdFile == null) {
        setState(() => _error = 'Please upload a photo of your Philippine Valid ID to create an owner account.');
        return;
      }
    }

    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      var user = await widget.firebaseService.signInOrRegister(
        email: _emailCtrl.text,
        password: _passwordCtrl.text,
        role: _role,
        isSignUp: _isSignUp,
        fullName: _isSignUp ? _nameCtrl.text : null,
        age: _isSignUp ? parsedAge : null,
        gender: _isSignUp ? _gender : null,
        school: (_isSignUp && _role == 'renter') ? _selectedSchool : null,
        ownerIdType: (_isSignUp && _role == 'owner') ? _idType : null,
      );

      if (_isSignUp && user.role == 'owner' && _pickedOwnerIdFile != null) {
        final idBytes = await widget.firebaseService.readFileBytes(_pickedOwnerIdFile!.path);
        final docUrl = await widget.firebaseService.uploadImageBytes(
          folder: 'verification_docs/${user.uid}',
          bytes: idBytes,
          fileName: _pickedOwnerIdFile!.name,
        );
        await widget.firebaseService.saveOwnerVerificationUrl(user.uid, _idType, docUrl);
        user = user.copyWith(ownerIdType: _idType, ownerVerificationDocUrl: docUrl);
      }

      if (_isSignUp && user.role == 'renter' && _pickedStudentIdFile != null) {
        final idBytes = await widget.firebaseService.readFileBytes(_pickedStudentIdFile!.path);
        final idUrl = await widget.firebaseService.uploadImageBytes(
          folder: 'student_ids/${user.uid}',
          bytes: idBytes,
          fileName: _pickedStudentIdFile!.name,
        );
        await widget.firebaseService.saveUserStudentIdUrl(user.uid, idUrl);
        user = user.copyWith(studentIdPhotoUrl: idUrl);
      }

      if (mounted) {
        widget.onAuthenticated(user);
      }
    } catch (e) {
      setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0E1615),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0E1615),
        foregroundColor: Colors.white,
        title: Text(
          _role == 'owner'
              ? (_isSignUp ? 'New Owner Registration' : 'Owner Log In')
              : (_isSignUp ? 'Create Student Account' : 'Renter Log In'),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(24),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              SegmentedButton<String>(
                segments: const [
                  ButtonSegment(value: 'renter', label: Text('Renter')),
                  ButtonSegment(value: 'owner', label: Text('Owner')),
                ],
                selected: {_role},
                onSelectionChanged: (val) => setState(() {
                  _role = val.first;
                  _error = null;
                }),
              ),
              const SizedBox(height: 18),
              Text(
                _role == 'owner'
                    ? (_isSignUp ? 'Create Owner Account' : 'Owner Log In')
                    : (_isSignUp ? 'Create Student Account' : 'Renter Log In'),
                style: GoogleFonts.fraunces(fontSize: 26, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 6),
              Text(
                _role == 'owner'
                    ? (_isSignUp
                        ? 'Verify your identity with a Philippine Valid ID to start listing Oroquieta City rooms.'
                        : 'Log in to go straight to your Owner Dashboard.')
                    : (_isSignUp
                        ? 'Enter your name, age, gender, Oroquieta school, and School ID / Valid ID / COR.'
                        : 'Log in to continue your Oroquieta City room search.'),
                style: const TextStyle(fontSize: 14, color: Colors.black54),
              ),
              const SizedBox(height: 16),

              if (_isSignUp) ...[
                TextField(
                  controller: _nameCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Full Name',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      flex: 2,
                      child: TextField(
                        controller: _ageCtrl,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(
                          labelText: 'Age',
                          border: OutlineInputBorder(),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      flex: 3,
                      child: DropdownButtonFormField<String>(
                        value: _gender,
                        decoration: const InputDecoration(
                          labelText: 'Gender',
                          border: OutlineInputBorder(),
                        ),
                        items: const [
                          DropdownMenuItem(value: 'Female', child: Text('Female')),
                          DropdownMenuItem(value: 'Male', child: Text('Male')),
                          DropdownMenuItem(value: 'Prefer not to say', child: Text('Prefer not to say')),
                        ],
                        onChanged: (v) => setState(() => _gender = v ?? 'Female'),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                if (_role == 'renter') ...[
                  DropdownButtonFormField<String>(
                    value: _selectedSchool,
                    isExpanded: true,
                    decoration: const InputDecoration(
                      labelText: 'School (Oroquieta City Only)',
                      border: OutlineInputBorder(),
                    ),
                    items: oroquietaCitySchools
                        .map((s) => DropdownMenuItem(
                              value: s.name,
                              child: Text('${s.name} (Brgy. ${s.barangay})', overflow: TextOverflow.ellipsis),
                            ))
                        .toList(),
                    onChanged: (v) => setState(() => _selectedSchool = v ?? oroquietaCitySchools.first.name),
                  ),
                  const SizedBox(height: 12),
                ],
              ],

              TextField(
                controller: _emailCtrl,
                keyboardType: TextInputType.emailAddress,
                decoration: const InputDecoration(
                  labelText: 'Email address',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _passwordCtrl,
                obscureText: true,
                decoration: const InputDecoration(
                  labelText: 'Password (min 6 chars)',
                  border: OutlineInputBorder(),
                ),
              ),

              if (_isSignUp && _role == 'renter') ...[
                const SizedBox(height: 14),
                OutlinedButton.icon(
                  onPressed: _pickStudentIdDoc,
                  icon: const Icon(Icons.badge),
                  label: Text(
                    _pickedStudentIdFile != null
                        ? 'Attached ID/COR: ${_pickedStudentIdFile!.name}'
                        : 'Upload School ID / Valid ID or COR (Required)',
                  ),
                ),
              ],

              if (_isSignUp && _role == 'owner') ...[
                const SizedBox(height: 14),
                DropdownButtonFormField<String>(
                  value: _idType,
                  isExpanded: true,
                  decoration: const InputDecoration(
                    labelText: 'Accepted Philippine Valid ID',
                    border: OutlineInputBorder(),
                  ),
                  items: philippineValidIds
                      .map((id) => DropdownMenuItem(
                            value: id,
                            child: Text(id, overflow: TextOverflow.ellipsis),
                          ))
                      .toList(),
                  onChanged: (v) => setState(() => _idType = v ?? philippineValidIds.first),
                ),
                const SizedBox(height: 10),
                OutlinedButton.icon(
                  onPressed: _pickOwnerValidIdDoc,
                  icon: const Icon(Icons.verified_user),
                  label: Text(
                    _pickedOwnerIdFile != null
                        ? 'Valid ID: ${_pickedOwnerIdFile!.name}'
                        : 'Upload Valid ID Photo (Required)',
                  ),
                ),
              ],

              if (_error != null) ...[
                const SizedBox(height: 12),
                Text(_error!, style: const TextStyle(color: Colors.red, fontSize: 15)),
              ],
              const SizedBox(height: 18),
              ElevatedButton(
                onPressed: _isLoading ? null : _submitCredentials,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFE05D26),
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                child: _isLoading
                    ? const CircularProgressIndicator(color: Colors.white)
                    : Text(
                        _role == 'owner'
                            ? (_isSignUp ? 'Create Account & Go to Owner Dashboard' : 'Log In')
                            : (_isSignUp ? 'Create Account & Show Rooms Near My School' : 'Log In'),
                      ),
              ),
              TextButton(
                onPressed: () => setState(() {
                  _isSignUp = !_isSignUp;
                  _error = null;
                  if (_isSignUp && _role == 'owner' && _ageCtrl.text == '19') {
                    _ageCtrl.text = '30';
                  }
                }),
                child: Text(
                  _isSignUp
                      ? 'Already have an account? Log in here'
                      : (_role == 'owner'
                          ? 'New to VRENT? Create an owner account'
                          : 'New to VRENT? Create a student account'),
                  style: const TextStyle(fontSize: 15),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
