import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import '../data/oroquieta_schools.dart';
import '../models/room.dart';
import '../services/firebase_service.dart';
import 'virtual_tour_screen.dart';

class OwnerDashboardScreen extends StatefulWidget {
  final FirebaseService firebaseService;
  final AppUser ownerUser;
  final VoidCallback onLogout;

  const OwnerDashboardScreen({
    super.key,
    required this.firebaseService,
    required this.ownerUser,
    required this.onLogout,
  });

  @override
  State<OwnerDashboardScreen> createState() => _OwnerDashboardScreenState();
}

class _OwnerDashboardScreenState extends State<OwnerDashboardScreen> {
  Future<void> _openAddRoomDialog() async {
    final defaultSchool = oroquietaCitySchools.first;
    final titleCtrl = TextEditingController();
    final priceCtrl = TextEditingController(text: '2500');
    final availCtrl = TextEditingController(text: '2');
    final totalCtrl = TextEditingController(text: '4');
    final walkCtrl = TextEditingController(text: '3');
    final brgyCtrl = TextEditingController(text: defaultSchool.barangay);
    final landmarkCtrl = TextEditingController(text: 'Near ${defaultSchool.shortName}');
    final locCtrl = TextEditingController(text: defaultSchool.defaultAddress);
    final amenitiesCtrl = TextEditingController(text: 'Wi-Fi, Study table, Water filter');
    final descCtrl = TextEditingController(text: 'Clean and safe student boarding room in Oroquieta City.');

    String selectedNearSchool = defaultSchool.name;
    String selectedType = 'Shared Room';
    String selectedGender = 'Mixed';
    String selectedUtilities = 'Water Included, Electric Submetered';
    RoomMedia? draftMedia;
    double lat = defaultSchool.lat;
    double lng = defaultSchool.lng;

    await showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setModalState) => AlertDialog(
          title: Text('Add Boarding Room (Oroquieta)', style: GoogleFonts.fraunces(fontWeight: FontWeight.w800)),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                DropdownButtonFormField<String>(
                  value: selectedNearSchool,
                  isExpanded: true,
                  decoration: const InputDecoration(labelText: 'Near Specific School (Oroquieta City Only)'),
                  items: oroquietaCitySchools
                      .map((s) => DropdownMenuItem(
                            value: s.name,
                            child: Text('${s.name} (Brgy. ${s.barangay})', overflow: TextOverflow.ellipsis),
                          ))
                      .toList(),
                  onChanged: (v) {
                    if (v == null) return;
                    final school = oroquietaCitySchools.firstWhere((s) => s.name == v, orElse: () => defaultSchool);
                    setModalState(() {
                      selectedNearSchool = school.name;
                      brgyCtrl.text = school.barangay;
                      landmarkCtrl.text = 'Near ${school.shortName}';
                      locCtrl.text = school.defaultAddress;
                      lat = school.lat;
                      lng = school.lng;
                    });
                  },
                ),
                TextField(controller: titleCtrl, decoration: const InputDecoration(labelText: 'Room Title')),
                DropdownButtonFormField<String>(
                  value: selectedType,
                  decoration: const InputDecoration(labelText: 'Room Type'),
                  items: const [
                    DropdownMenuItem(value: 'Private Room', child: Text('Private Room')),
                    DropdownMenuItem(value: 'Shared Room', child: Text('Shared Room')),
                    DropdownMenuItem(value: 'Studio', child: Text('Studio')),
                    DropdownMenuItem(value: 'Dormitory Bed', child: Text('Dormitory Bed')),
                  ],
                  onChanged: (v) => setModalState(() => selectedType = v ?? selectedType),
                ),
                DropdownButtonFormField<String>(
                  value: selectedGender,
                  decoration: const InputDecoration(labelText: 'Gender Policy'),
                  items: const [
                    DropdownMenuItem(value: 'Mixed', child: Text('Mixed')),
                    DropdownMenuItem(value: 'Female Only', child: Text('Female Only')),
                    DropdownMenuItem(value: 'Male Only', child: Text('Male Only')),
                  ],
                  onChanged: (v) => setModalState(() => selectedGender = v ?? selectedGender),
                ),
                DropdownButtonFormField<String>(
                  value: selectedUtilities,
                  decoration: const InputDecoration(labelText: 'Utilities Policy'),
                  items: const [
                    DropdownMenuItem(value: 'Water & Electric Included', child: Text('Water & Electric Included')),
                    DropdownMenuItem(value: 'Water Included, Electric Submetered', child: Text('Water Included, Electric Submetered')),
                    DropdownMenuItem(value: 'Submetered', child: Text('Submetered')),
                  ],
                  onChanged: (v) => setModalState(() => selectedUtilities = v ?? selectedUtilities),
                ),
                TextField(controller: priceCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Monthly Rent (₱)')),
                TextField(controller: availCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Available Slots')),
                TextField(controller: totalCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Total Slots')),
                TextField(controller: walkCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Walking Minutes')),
                TextField(controller: brgyCtrl, decoration: const InputDecoration(labelText: 'Barangay (Oroquieta City)')),
                TextField(controller: landmarkCtrl, decoration: const InputDecoration(labelText: 'Asa Dapita / Landmark')),
                TextField(controller: locCtrl, decoration: const InputDecoration(labelText: 'Full Address (Oroquieta City)')),
                TextField(controller: amenitiesCtrl, decoration: const InputDecoration(labelText: 'Amenities (comma separated)')),
                TextField(controller: descCtrl, maxLines: 2, decoration: const InputDecoration(labelText: 'Description')),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () async {
                          final picked = await ImagePicker().pickImage(source: ImageSource.gallery);
                          if (picked == null) return;
                          final bytes = await widget.firebaseService.readFileBytes(picked.path);
                          final uploaded = await widget.firebaseService.uploadRoomMediaFile(
                            roomId: 'room-${DateTime.now().millisecondsSinceEpoch}',
                            type: 'panorama',
                            bytes: bytes,
                            fileName: picked.name,
                          );
                          setModalState(() => draftMedia = uploaded);
                        },
                        icon: const Icon(Icons.panorama),
                        label: const Text('360° Photo'),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () async {
                          final picked = await ImagePicker().pickVideo(source: ImageSource.gallery);
                          if (picked == null) return;
                          final bytes = await widget.firebaseService.prepareVideoBytesForUpload(picked.path);
                          final uploaded = await widget.firebaseService.uploadRoomMediaFile(
                            roomId: 'room-${DateTime.now().millisecondsSinceEpoch}',
                            type: 'video',
                            bytes: bytes,
                            fileName: picked.name,
                          );
                          setModalState(() => draftMedia = uploaded);
                        },
                        icon: const Icon(Icons.videocam),
                        label: const Text('Video'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
            ElevatedButton(
              onPressed: () async {
                final roomId = 'room-${DateTime.now().millisecondsSinceEpoch}';
                final total = (int.tryParse(totalCtrl.text) ?? 4).clamp(1, 50);
                final avail = (int.tryParse(availCtrl.text) ?? 2).clamp(0, total);
                final price = int.tryParse(priceCtrl.text) ?? 2500;
                final shared = selectedType == 'Shared Room' || selectedType == 'Dormitory Bed';
                final amenities = amenitiesCtrl.text
                    .split(',')
                    .map((e) => e.trim())
                    .where((e) => e.isNotEmpty)
                    .toList();
                final subUnits = List.generate(
                  total,
                  (i) => SubUnit(
                    id: '$roomId-u$i',
                    unitNumber: shared ? 'Bedspace ${String.fromCharCode(65 + i)}' : 'Unit ${101 + i}',
                    unitType: selectedType,
                    price: price,
                    status: i < avail ? 'available' : 'occupied',
                    features: amenities.take(4).toList(),
                  ),
                );
                final newRoom = Room(
                  id: roomId,
                  title: titleCtrl.text.trim().isEmpty ? 'New Oroquieta Room' : titleCtrl.text.trim(),
                  type: selectedType,
                  location: locCtrl.text.trim(),
                  city: 'Oroquieta',
                  barangay: brgyCtrl.text.trim(),
                  nearSchool: selectedNearSchool,
                  landmark: landmarkCtrl.text.trim(),
                  distanceKm: 0.4,
                  walkingMinutes: int.tryParse(walkCtrl.text) ?? 3,
                  genderPolicy: selectedGender,
                  utilitiesIncluded: selectedUtilities,
                  price: price,
                  amenities: amenities,
                  tags: [
                    'Student friendly',
                    'Verified Owner',
                    selectedGender,
                    if (selectedUtilities != 'Submetered') 'Water Included',
                  ],
                  slotsAvailable: avail,
                  totalSlots: total,
                  availableFrom: DateTime.now().toIso8601String().split('T').first,
                  description: descCtrl.text.trim(),
                  rules: const ['Curfew 10:00 PM', 'Quiet study hours'],
                  ownerName: widget.ownerUser.name,
                  ownerPhone: '+63 917 554 1289',
                  ownerId: widget.ownerUser.uid,
                  ownerVerified: true,
                  lat: lat,
                  lng: lng,
                  subUnits: subUnits,
                  roomMedia: draftMedia,
                );
                await widget.firebaseService.addRoom(newRoom);
                if (ctx.mounted) Navigator.pop(ctx);
              },
              style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFE05D26), foregroundColor: Colors.white),
              child: const Text('Publish Room'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _openEditRoomDialog(Room room) async {
    final titleCtrl = TextEditingController(text: room.title);
    final priceCtrl = TextEditingController(text: room.price.toString());
    final availCtrl = TextEditingController(text: room.slotsAvailable.toString());
    final totalCtrl = TextEditingController(text: room.totalSlots.toString());
    final walkCtrl = TextEditingController(text: room.walkingMinutes.toString());
    final brgyCtrl = TextEditingController(text: room.barangay);
    final landmarkCtrl = TextEditingController(text: room.landmark);
    final locCtrl = TextEditingController(text: room.location);
    final amenitiesCtrl = TextEditingController(text: room.amenities.join(', '));
    final descCtrl = TextEditingController(text: room.description);
    final rulesCtrl = TextEditingController(text: room.rules.join(', '));

    String selectedNearSchool = room.nearSchool != null &&
            oroquietaCitySchools.any((s) => s.name == room.nearSchool)
        ? room.nearSchool!
        : oroquietaCitySchools.first.name;
    String selectedType = room.type;
    String selectedGender = room.genderPolicy;
    String selectedUtilities = room.utilitiesIncluded;
    double lat = room.lat;
    double lng = room.lng;
    RoomMedia? draftMedia = room.roomMedia;

    await showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setModalState) => AlertDialog(
          title: Text('Edit ${room.title}', style: GoogleFonts.fraunces(fontWeight: FontWeight.w800)),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                DropdownButtonFormField<String>(
                  value: selectedNearSchool,
                  isExpanded: true,
                  decoration: const InputDecoration(labelText: 'Near Specific School (Oroquieta City Only)'),
                  items: oroquietaCitySchools
                      .map((s) => DropdownMenuItem(
                            value: s.name,
                            child: Text('${s.name} (Brgy. ${s.barangay})', overflow: TextOverflow.ellipsis),
                          ))
                      .toList(),
                  onChanged: (v) {
                    if (v == null) return;
                    final school = oroquietaCitySchools.firstWhere(
                      (s) => s.name == v,
                      orElse: () => oroquietaCitySchools.first,
                    );
                    setModalState(() {
                      selectedNearSchool = school.name;
                      brgyCtrl.text = school.barangay;
                      landmarkCtrl.text = 'Near ${school.shortName}';
                      locCtrl.text = school.defaultAddress;
                      lat = school.lat;
                      lng = school.lng;
                    });
                  },
                ),
                TextField(controller: titleCtrl, decoration: const InputDecoration(labelText: 'Room Title')),
                DropdownButtonFormField<String>(
                  value: selectedType,
                  decoration: const InputDecoration(labelText: 'Room Type'),
                  items: const [
                    DropdownMenuItem(value: 'Private Room', child: Text('Private Room')),
                    DropdownMenuItem(value: 'Shared Room', child: Text('Shared Room')),
                    DropdownMenuItem(value: 'Studio', child: Text('Studio')),
                    DropdownMenuItem(value: 'Dormitory Bed', child: Text('Dormitory Bed')),
                  ],
                  onChanged: (v) => setModalState(() => selectedType = v ?? selectedType),
                ),
                DropdownButtonFormField<String>(
                  value: selectedGender,
                  decoration: const InputDecoration(labelText: 'Gender Policy'),
                  items: const [
                    DropdownMenuItem(value: 'Mixed', child: Text('Mixed')),
                    DropdownMenuItem(value: 'Female Only', child: Text('Female Only')),
                    DropdownMenuItem(value: 'Male Only', child: Text('Male Only')),
                  ],
                  onChanged: (v) => setModalState(() => selectedGender = v ?? selectedGender),
                ),
                DropdownButtonFormField<String>(
                  value: selectedUtilities,
                  decoration: const InputDecoration(labelText: 'Utilities Policy'),
                  items: const [
                    DropdownMenuItem(value: 'Water & Electric Included', child: Text('Water & Electric Included')),
                    DropdownMenuItem(value: 'Water Included, Electric Submetered', child: Text('Water Included, Electric Submetered')),
                    DropdownMenuItem(value: 'Submetered', child: Text('Submetered')),
                  ],
                  onChanged: (v) => setModalState(() => selectedUtilities = v ?? selectedUtilities),
                ),
                TextField(controller: priceCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Monthly Rent (₱)')),
                TextField(controller: availCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Available Slots')),
                TextField(controller: totalCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Total Slots')),
                TextField(controller: walkCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Walking Minutes to Campus')),
                TextField(controller: brgyCtrl, decoration: const InputDecoration(labelText: 'Barangay (Oroquieta City)')),
                TextField(controller: landmarkCtrl, decoration: const InputDecoration(labelText: 'Asa Dapita / Landmark')),
                TextField(controller: locCtrl, decoration: const InputDecoration(labelText: 'Full Address')),
                TextField(controller: amenitiesCtrl, decoration: const InputDecoration(labelText: 'Amenities (comma separated)')),
                TextField(controller: descCtrl, maxLines: 2, decoration: const InputDecoration(labelText: 'Description')),
                TextField(controller: rulesCtrl, decoration: const InputDecoration(labelText: 'Rules (comma separated)')),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () async {
                          final picked = await ImagePicker().pickImage(source: ImageSource.gallery);
                          if (picked == null) return;
                          final bytes = await widget.firebaseService.readFileBytes(picked.path);
                          final uploaded = await widget.firebaseService.uploadRoomMediaFile(
                            roomId: room.id,
                            type: 'panorama',
                            bytes: bytes,
                            fileName: picked.name,
                          );
                          setModalState(() => draftMedia = uploaded);
                        },
                        icon: const Icon(Icons.panorama),
                        label: const Text('Upload 360°'),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () async {
                          final picked = await ImagePicker().pickVideo(source: ImageSource.gallery);
                          if (picked == null) return;
                          final bytes = await widget.firebaseService.prepareVideoBytesForUpload(picked.path);
                          final uploaded = await widget.firebaseService.uploadRoomMediaFile(
                            roomId: room.id,
                            type: 'video',
                            bytes: bytes,
                            fileName: picked.name,
                          );
                          setModalState(() => draftMedia = uploaded);
                        },
                        icon: const Icon(Icons.videocam),
                        label: const Text('Upload Video'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
            ElevatedButton(
              onPressed: () async {
                final total = int.tryParse(totalCtrl.text) ?? room.totalSlots;
                final avail = (int.tryParse(availCtrl.text) ?? room.slotsAvailable).clamp(0, total);
                final updated = room.copyWith(
                  title: titleCtrl.text.trim(),
                  type: selectedType,
                  genderPolicy: selectedGender,
                  utilitiesIncluded: selectedUtilities,
                  walkingMinutes: int.tryParse(walkCtrl.text) ?? room.walkingMinutes,
                  price: int.tryParse(priceCtrl.text) ?? room.price,
                  slotsAvailable: avail,
                  totalSlots: total,
                  barangay: brgyCtrl.text.trim(),
                  nearSchool: selectedNearSchool,
                  landmark: landmarkCtrl.text.trim(),
                  location: locCtrl.text.trim(),
                  lat: lat,
                  lng: lng,
                  amenities: amenitiesCtrl.text.split(',').map((e) => e.trim()).where((e) => e.isNotEmpty).toList(),
                  description: descCtrl.text.trim(),
                  rules: rulesCtrl.text.split(',').map((e) => e.trim()).where((e) => e.isNotEmpty).toList(),
                  roomMedia: draftMedia,
                );
                await widget.firebaseService.updateRoom(updated);
                if (ctx.mounted) Navigator.pop(ctx);
              },
              style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFE05D26), foregroundColor: Colors.white),
              child: const Text('Save Changes'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _openAnnouncementDialog() async {
    final titleCtrl = TextEditingController();
    final msgCtrl = TextEditingController();
    String priority = 'important';
    await showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setModalState) => AlertDialog(
          title: const Text('Broadcast Tenant Notice'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: titleCtrl, decoration: const InputDecoration(labelText: 'Subject')),
              DropdownButtonFormField<String>(
                value: priority,
                decoration: const InputDecoration(labelText: 'Priority'),
                items: const [
                  DropdownMenuItem(value: 'important', child: Text('Important')),
                  DropdownMenuItem(value: 'normal', child: Text('Normal')),
                ],
                onChanged: (v) => setModalState(() => priority = v ?? 'important'),
              ),
              TextField(controller: msgCtrl, maxLines: 3, decoration: const InputDecoration(labelText: 'Message')),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
            ElevatedButton(
              onPressed: () async {
                await widget.firebaseService.postAnnouncement(
                  OwnerAnnouncement(
                    id: '',
                    ownerId: widget.ownerUser.uid,
                    title: titleCtrl.text.trim(),
                    message: msgCtrl.text.trim(),
                    priority: priority,
                    date: DateTime.now().toIso8601String().split('T').first,
                    author: widget.ownerUser.name,
                  ),
                );
                if (ctx.mounted) Navigator.pop(ctx);
              },
              child: const Text('Publish'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFAF7F2),
      appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: const Color(0xFF0E1615),
        foregroundColor: Colors.white,
        title: Text('Owner · ${widget.ownerUser.name}'),
        actions: [
          IconButton(onPressed: _openAddRoomDialog, icon: const Icon(Icons.add_home_work), tooltip: 'Add Room'),
          IconButton(onPressed: _openAnnouncementDialog, icon: const Icon(Icons.campaign), tooltip: 'Post Announcement'),
          TextButton.icon(
            onPressed: widget.onLogout,
            icon: const Icon(Icons.logout, color: Colors.white70, size: 18),
            label: const Text('Log out', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _openAddRoomDialog,
        backgroundColor: const Color(0xFFE05D26),
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add),
        label: const Text('Add Room'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('Your Active Rooms', style: GoogleFonts.fraunces(fontSize: 24, fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),
          StreamBuilder<List<Room>>(
            stream: widget.firebaseService.watchOwnerRooms(widget.ownerUser.uid),
            builder: (context, snap) {
              final rooms = snap.data ?? [];
              if (rooms.isEmpty) {
                return Card(
                  color: Colors.white,
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      children: [
                        const Text('No rooms listed yet.', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 6),
                        const Text('Tap + Add Room to list your boarding house room & Oroquieta school location.', textAlign: TextAlign.center),
                        const SizedBox(height: 12),
                        ElevatedButton.icon(
                          onPressed: _openAddRoomDialog,
                          style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFE05D26), foregroundColor: Colors.white),
                          icon: const Icon(Icons.add),
                          label: const Text('Add Your First Room'),
                        ),
                      ],
                    ),
                  ),
                );
              }
              return Column(
                children: rooms.map((room) => Card(
                  color: Colors.white,
                  margin: const EdgeInsets.only(bottom: 12),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(child: Text(room.title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
                            Text('₱${room.price}/mo', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: Color(0xFFE05D26))),
                          ],
                        ),
                        const SizedBox(height: 4),
                        Text('${room.location} · ${room.slotsAvailable}/${room.totalSlots} free · ${room.genderPolicy}'),
                        if (room.nearSchool != null)
                          Text('Near ${room.nearSchool}', style: const TextStyle(color: Color(0xFFC94F1C), fontWeight: FontWeight.w700)),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            Expanded(
                              child: ElevatedButton.icon(
                                onPressed: () => Navigator.of(context).push(
                                  MaterialPageRoute(builder: (_) => VirtualTourScreen(room: room)),
                                ),
                                icon: Icon(room.roomMedia?.type == 'video' ? Icons.play_circle : Icons.visibility),
                                label: Text(room.roomMedia?.type == 'video' ? 'View Video' : 'View Tour'),
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: OutlinedButton.icon(
                                onPressed: () => _openEditRoomDialog(room),
                                icon: const Icon(Icons.edit),
                                label: const Text('Edit Room'),
                              ),
                            ),
                            IconButton(
                              onPressed: () => widget.firebaseService.deleteRoom(room.id),
                              icon: const Icon(Icons.delete_outline, color: Colors.red),
                              tooltip: 'Delete Room',
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                )).toList(),
              );
            },
          ),
          const SizedBox(height: 18),
          Text('Tenant Booking Requests', style: GoogleFonts.fraunces(fontSize: 24, fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),
          StreamBuilder<List<BookingRequest>>(
            stream: widget.firebaseService.watchOwnerBookingRequests(widget.ownerUser.uid),
            builder: (context, snap) {
              final requests = snap.data ?? [];
              if (requests.isEmpty) return const Text('No booking requests yet.');
              return Column(
                children: requests.map((req) => Card(
                  color: Colors.white,
                  margin: const EdgeInsets.only(bottom: 10),
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('${req.renterName} (${req.status.toUpperCase()})', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                        Text('${req.roomTitle}${req.unitNumber != null ? ' · ${req.unitNumber}' : ''} · Move-in: ${req.moveInDate}'),
                        if (req.renterAge != null || req.renterGender != null || req.renterSchool != null)
                          Text(
                            [
                              if (req.renterAge != null) 'Age: ${req.renterAge}',
                              if (req.renterGender != null) 'Gender: ${req.renterGender}',
                              if (req.renterSchool != null) 'School: ${req.renterSchool}',
                            ].join(' · '),
                            style: const TextStyle(fontSize: 13, color: Colors.black87, fontWeight: FontWeight.w600),
                          ),
                        if (req.studentIdPhotoUrl != null)
                          const Text('✓ Student ID / COR attached', style: TextStyle(color: Colors.indigo, fontWeight: FontWeight.bold)),
                        if (req.status == 'pending') ...[
                          const SizedBox(height: 8),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              TextButton(
                                onPressed: () => widget.firebaseService.declineBookingRequest(req.id),
                                child: const Text('Decline', style: TextStyle(color: Colors.red)),
                              ),
                              ElevatedButton(
                                onPressed: () => widget.firebaseService.approveBookingAndSyncSlot(req),
                                style: ElevatedButton.styleFrom(backgroundColor: Colors.green, foregroundColor: Colors.white),
                                child: const Text('Approve & Sync Slot'),
                              ),
                            ],
                          ),
                        ],
                      ],
                    ),
                  ),
                )).toList(),
              );
            },
          ),
          const SizedBox(height: 18),
          Text('GCash & Bank Receipts', style: GoogleFonts.fraunces(fontSize: 24, fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),
          StreamBuilder<List<PaymentRecord>>(
            stream: widget.firebaseService.watchOwnerPayments(widget.ownerUser.uid),
            builder: (context, snap) {
              final payments = snap.data ?? [];
              if (payments.isEmpty) return const Text('No payment receipts submitted yet.');
              return Column(
                children: payments.map((pay) => Card(
                  color: Colors.white,
                  margin: const EdgeInsets.only(bottom: 10),
                  child: ListTile(
                    title: Text('${pay.renterName} · ₱${pay.amount} (${pay.method})', style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text('${pay.roomTitle} · Ref ${pay.referenceNo} · ${pay.status.toUpperCase()}'),
                    trailing: pay.status == 'pending'
                        ? ElevatedButton(
                            onPressed: () => widget.firebaseService.verifyPayment(pay.id),
                            style: ElevatedButton.styleFrom(backgroundColor: Colors.green, foregroundColor: Colors.white),
                            child: const Text('Verify'),
                          )
                        : const Icon(Icons.verified, color: Colors.green),
                  ),
                )).toList(),
              );
            },
          ),
        ],
      ),
    );
  }
}
