import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../models/room.dart';
import '../services/firebase_service.dart';

class RenterBookingsScreen extends StatelessWidget {
  final FirebaseService firebaseService;
  final AppUser? currentUser;
  final DateTime sessionStart;

  const RenterBookingsScreen({
    super.key,
    required this.firebaseService,
    required this.currentUser,
    required this.sessionStart,
  });

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        backgroundColor: const Color(0xFFFAF7F2),
        appBar: AppBar(
          backgroundColor: const Color(0xFF0E1615),
          foregroundColor: Colors.white,
          title: Text('My Bookings & Notices', style: GoogleFonts.fraunces(fontWeight: FontWeight.w800)),
          bottom: const TabBar(
            indicatorColor: Color(0xFFE05D26),
            labelColor: Colors.white,
            unselectedLabelColor: Colors.white60,
            tabs: [
              Tab(text: 'Bookings'),
              Tab(text: 'Receipts'),
              Tab(text: 'Notices'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            _buildBookingsTab(),
            _buildReceiptsTab(),
            _buildNoticesTab(),
          ],
        ),
      ),
    );
  }

  Widget _buildBookingsTab() {
    if (currentUser == null) {
      return const Center(child: Text('Sign in as a Renter to track your bookings.', style: TextStyle(fontSize: 16)));
    }
    return StreamBuilder<List<BookingRequest>>(
      stream: firebaseService.watchBookingRequests(),
      builder: (context, snap) {
        final list = (snap.data ?? []).where((r) {
          if (r.renterId != currentUser!.uid) return false;
          final dt = DateTime.tryParse(r.createdAt);
          return dt == null || !dt.isBefore(sessionStart);
        }).toList();
        if (list.isEmpty) {
          return const Center(child: Text('No booking requests yet.', style: TextStyle(fontSize: 16)));
        }
        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: list.length,
          itemBuilder: (_, i) {
            final req = list[i];
            return Card(
              margin: const EdgeInsets.only(bottom: 12),
              child: ListTile(
                title: Text(req.roomTitle, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                subtitle: Text(
                  '${req.unitNumber ?? 'Assigned upon arrival'} · Move-in ${req.moveInDate} · ₱${req.roomPrice}/mo',
                ),
                trailing: Chip(
                  label: Text(req.status.toUpperCase(), style: const TextStyle(fontWeight: FontWeight.bold)),
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildReceiptsTab() {
    if (currentUser == null) {
      return const Center(child: Text('Sign in as a Renter to view your receipts.', style: TextStyle(fontSize: 16)));
    }
    return StreamBuilder<List<PaymentRecord>>(
      stream: firebaseService.watchPayments(),
      builder: (context, snap) {
        final list = (snap.data ?? []).where((p) {
          if (p.renterId != currentUser!.uid) return false;
          final dt = DateTime.tryParse(p.paidDate);
          return dt == null || !dt.isBefore(DateTime(sessionStart.year, sessionStart.month, sessionStart.day));
        }).toList();
        if (list.isEmpty) {
          return const Center(child: Text('No payment receipts submitted yet.', style: TextStyle(fontSize: 16)));
        }
        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: list.length,
          itemBuilder: (_, i) {
            final pay = list[i];
            return Card(
              margin: const EdgeInsets.only(bottom: 12),
              child: ListTile(
                title: Text('₱${pay.amount} · ${pay.roomTitle}', style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text('${pay.method} · Ref ${pay.referenceNo} · ${pay.monthCovered}'),
                trailing: Chip(
                  backgroundColor: pay.status == 'confirmed' ? Colors.green.shade100 : Colors.amber.shade100,
                  label: Text(
                    pay.status == 'confirmed' ? 'CONFIRMED' : 'PENDING',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildNoticesTab() {
    return StreamBuilder<List<OwnerAnnouncement>>(
      stream: firebaseService.watchAnnouncements(),
      builder: (context, snap) {
        final list = snap.data ?? [];
        if (list.isEmpty) {
          return const Center(child: Text('No announcements posted yet.', style: TextStyle(fontSize: 16)));
        }
        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: list.length,
          itemBuilder: (_, i) {
            final ann = list[i];
            return Card(
              color: ann.priority == 'important' ? Colors.amber.shade50 : Colors.white,
              margin: const EdgeInsets.only(bottom: 12),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(ann.title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 6),
                    Text(ann.message, style: const TextStyle(fontSize: 15)),
                    const SizedBox(height: 6),
                    Text('${ann.author} · ${ann.date}', style: const TextStyle(fontSize: 13, color: Colors.black54)),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }
}
