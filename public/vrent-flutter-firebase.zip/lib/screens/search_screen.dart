import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../data/oroquieta_schools.dart';
import '../models/room.dart';
import '../services/firebase_service.dart';
import '../widgets/booking_sheet.dart';
import '../widgets/chat_sheet.dart';
import '../widgets/payment_sheet.dart';
import '../widgets/room_card.dart';
import '../widgets/units_directory_sheet.dart';
import 'renter_bookings_screen.dart';
import 'virtual_tour_screen.dart';

class SearchScreen extends StatefulWidget {
  final FirebaseService firebaseService;
  final AppUser? currentUser;
  final DateTime sessionStart;
  final void Function(String role) onOpenAuth;
  final VoidCallback onLogout;

  const SearchScreen({
    super.key,
    required this.firebaseService,
    required this.currentUser,
    required this.sessionStart,
    required this.onOpenAuth,
    required this.onLogout,
  });

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  String _query = '';
  String? _selectedBarangay;
  String? _selectedSchool;
  String _genderFilter = 'all';
  String _utilitiesFilter = 'all';

  @override
  void initState() {
    super.initState();
    if (widget.currentUser?.role == 'renter' && widget.currentUser?.school != null) {
      _selectedSchool = widget.currentUser!.school;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFAF7F2),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0E1615),
        foregroundColor: Colors.white,
        title: const Text('vrent · Oroquieta City'),
        actions: [
          if (widget.currentUser != null && widget.currentUser!.role == 'renter')
            TextButton(
              onPressed: () {
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => RenterBookingsScreen(
                      firebaseService: widget.firebaseService,
                      currentUser: widget.currentUser,
                      sessionStart: widget.sessionStart,
                    ),
                  ),
                );
              },
              child: const Text('My Bookings', style: TextStyle(color: Color(0xFFFDE68A), fontWeight: FontWeight.bold)),
            ),
          if (widget.currentUser != null) ...[
            if (widget.currentUser!.role == 'owner')
              TextButton(
                onPressed: () => widget.onOpenAuth('owner'),
                child: const Text('Dashboard', style: TextStyle(color: Colors.white)),
              ),
            TextButton(
              onPressed: widget.onLogout,
              child: const Text('Log out', style: TextStyle(color: Colors.white70)),
            ),
          ] else ...[
            TextButton(
              onPressed: () => widget.onOpenAuth('renter'),
              child: const Text('Renter', style: TextStyle(color: Colors.white)),
            ),
            Padding(
              padding: const EdgeInsets.only(right: 8),
              child: ElevatedButton(
                onPressed: () => widget.onOpenAuth('owner'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFE05D26),
                  foregroundColor: Colors.white,
                ),
                child: const Text('Owner'),
              ),
            ),
          ],
        ],
      ),
      body: Column(
        children: [
          Container(
            width: double.infinity,
            color: const Color(0xFF0E1615),
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Boarding Houses in Oroquieta City',
                  style: GoogleFonts.fraunces(
                    color: Colors.white,
                    fontSize: 24,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  onChanged: (v) => setState(() => _query = v),
                  style: const TextStyle(fontSize: 16, color: Colors.black87),
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: Colors.white,
                    prefixIcon: const Icon(Icons.search, color: Color(0xFFE05D26)),
                    hintText: 'Search Oroquieta school, barangay, or room...',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton<String?>(
                      isExpanded: true,
                      value: _selectedSchool,
                      hint: const Text('Filter by School (Oroquieta City Only)'),
                      items: [
                        const DropdownMenuItem<String?>(
                          value: null,
                          child: Text('All Oroquieta City Schools'),
                        ),
                        ...oroquietaCitySchools.map(
                          (s) => DropdownMenuItem<String?>(
                            value: s.name,
                            child: Text(s.shortName, overflow: TextOverflow.ellipsis),
                          ),
                        ),
                      ],
                      onChanged: (v) => setState(() => _selectedSchool = v),
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      for (final b in ['All', 'Mobod', 'Poblacion', 'Lower Langcangan'])
                        Padding(
                          padding: const EdgeInsets.only(right: 8),
                          child: ChoiceChip(
                            label: Text(b),
                            selected: (b == 'All' && _selectedBarangay == null) || _selectedBarangay == b,
                            onSelected: (_) => setState(() => _selectedBarangay = b == 'All' ? null : b),
                          ),
                        ),
                      for (final g in ['Mixed', 'Female Only', 'Male Only'])
                        Padding(
                          padding: const EdgeInsets.only(right: 8),
                          child: FilterChip(
                            label: Text(g),
                            selected: _genderFilter == g,
                            onSelected: (sel) => setState(() => _genderFilter = sel ? g : 'all'),
                          ),
                        ),
                      FilterChip(
                        label: const Text('Water Included'),
                        selected: _utilitiesFilter == 'water',
                        onSelected: (sel) => setState(() => _utilitiesFilter = sel ? 'water' : 'all'),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          if (widget.currentUser?.role == 'renter' && widget.currentUser?.school != null)
            Container(
              width: double.infinity,
              color: const Color(0xFFFFF7ED),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              child: Row(
                children: [
                  const Icon(Icons.school, color: Color(0xFFE05D26), size: 20),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      _selectedSchool != null
                          ? 'Showing rooms near $_selectedSchool (Oroquieta City only)'
                          : 'Verified Student: ${widget.currentUser!.name} (${widget.currentUser!.school})',
                      style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
                    ),
                  ),
                  TextButton(
                    onPressed: () => setState(() {
                      _selectedSchool = _selectedSchool == null ? widget.currentUser!.school : null;
                    }),
                    child: Text(_selectedSchool == null ? 'My School' : 'Show All'),
                  ),
                ],
              ),
            ),
          Expanded(
            child: StreamBuilder<List<Room>>(
              stream: widget.firebaseService.watchOroquietaRooms(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                final rooms = (snapshot.data ?? []).where((room) {
                  if (!room.city.toLowerCase().contains('oroquieta')) {
                    return false;
                  }
                  if (_selectedSchool != null) {
                    final schoolObj = oroquietaCitySchools.firstWhere(
                      (s) => s.name == _selectedSchool,
                      orElse: () => oroquietaCitySchools.first,
                    );
                    if (room.nearSchool != null && room.nearSchool!.isNotEmpty) {
                      final exact = room.nearSchool!.toLowerCase() == _selectedSchool!.toLowerCase() ||
                          room.nearSchool!.toLowerCase().contains(schoolObj.shortName.toLowerCase());
                      if (!exact) return false;
                    } else {
                      final hay = '${room.landmark} ${room.location} ${room.barangay}'.toLowerCase();
                      if (!hay.contains(schoolObj.shortName.toLowerCase()) &&
                          !hay.contains(schoolObj.barangay.toLowerCase())) {
                        return false;
                      }
                    }
                  }
                  if (_selectedBarangay != null && room.barangay.toLowerCase() != _selectedBarangay!.toLowerCase()) {
                    return false;
                  }
                  if (_genderFilter != 'all' && room.genderPolicy != _genderFilter) {
                    return false;
                  }
                  if (_utilitiesFilter == 'water' && room.utilitiesIncluded == 'Submetered') {
                    return false;
                  }
                  if (_query.trim().isNotEmpty) {
                    final q = _query.toLowerCase();
                    return room.title.toLowerCase().contains(q) ||
                        room.location.toLowerCase().contains(q) ||
                        room.landmark.toLowerCase().contains(q) ||
                        (room.nearSchool ?? '').toLowerCase().contains(q);
                  }
                  return true;
                }).toList();
                if (rooms.isEmpty) {
                  return Center(
                    child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: Text(
                        (_selectedSchool == null &&
                                _selectedBarangay == null &&
                                _genderFilter == 'all' &&
                                _utilitiesFilter == 'all' &&
                                _query.trim().isEmpty)
                            ? 'No rooms listed by owners yet. Once owners add rooms in Owner Dashboard, they appear here live.'
                            : 'No Oroquieta rooms match your selected school or filter.',
                        textAlign: TextAlign.center,
                        style: const TextStyle(fontSize: 17),
                      ),
                    ),
                  );
                }
                return ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: rooms.length,
                  itemBuilder: (_, index) {
                    final room = rooms[index];
                    return RoomCard(
                      room: room,
                      onOpenTour: () {
                        Navigator.of(context).push(
                          MaterialPageRoute(builder: (_) => VirtualTourScreen(room: room)),
                        );
                      },
                      onOpenUnits: () {
                        showModalBottomSheet(
                          context: context,
                          isScrollControlled: true,
                          builder: (_) => UnitsDirectorySheet(
                            room: room,
                            onSelectUnit: (unit) {
                              Navigator.pop(context);
                              if (widget.currentUser == null) {
                                widget.onOpenAuth('renter');
                                return;
                              }
                              _openBooking(context, room, unit.unitNumber);
                            },
                          ),
                        );
                      },
                      onOpenChat: () {
                        showModalBottomSheet(
                          context: context,
                          isScrollControlled: true,
                          builder: (_) => ChatSheet(
                            room: room,
                            firebaseService: widget.firebaseService,
                            currentUser: widget.currentUser,
                          ),
                        );
                      },
                      onOpenPayment: () {
                        showModalBottomSheet(
                          context: context,
                          isScrollControlled: true,
                          builder: (_) => PaymentSheet(
                            room: room,
                            firebaseService: widget.firebaseService,
                            currentUser: widget.currentUser,
                          ),
                        );
                      },
                      onBook: () => _openBooking(context, room, null),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  void _openBooking(BuildContext context, Room room, String? unitNumber) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => BookingSheet(
        room: room,
        initialUnitNumber: unitNumber,
        firebaseService: widget.firebaseService,
        currentUser: widget.currentUser,
      ),
    );
  }
}
