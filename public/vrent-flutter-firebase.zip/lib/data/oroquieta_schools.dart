class OroquietaSchool {
  final String id;
  final String name;
  final String shortName;
  final String barangay;
  final String defaultAddress;
  final double lat;
  final double lng;

  const OroquietaSchool({
    required this.id,
    required this.name,
    required this.shortName,
    required this.barangay,
    required this.defaultAddress,
    required this.lat,
    required this.lng,
  });
}

const List<OroquietaSchool> oroquietaCitySchools = [
  OroquietaSchool(
    id: 'ustp-oroquieta',
    name: 'USTP Oroquieta Campus',
    shortName: 'USTP Oroquieta',
    barangay: 'Mobod',
    defaultAddress: 'Purok 2, Brgy. Mobod, Oroquieta City',
    lat: 8.4895,
    lng: 123.8038,
  ),
  OroquietaSchool(
    id: 'sjc-oroquieta',
    name: 'Saint Joseph College (SJC) - Oroquieta City',
    shortName: 'Saint Joseph College (SJC)',
    barangay: 'Canubay',
    defaultAddress: 'National Highway, Brgy. Canubay, Oroquieta City',
    lat: 8.4840,
    lng: 123.8010,
  ),
  OroquietaSchool(
    id: 'scc-oroquieta',
    name: 'Southern Capital Colleges (SCC)',
    shortName: 'Southern Capital Colleges',
    barangay: 'Poblacion',
    defaultAddress: 'Washington St., Brgy. Poblacion, Oroquieta City',
    lat: 8.4855,
    lng: 123.8070,
  ),
  OroquietaSchool(
    id: 'moit-oroquieta',
    name: 'Misamis Occidental Institute of Technology (MOIT)',
    shortName: 'MOIT Oroquieta',
    barangay: 'Lower Langcangan',
    defaultAddress: 'Purok 3, Brgy. Lower Langcangan, Oroquieta City',
    lat: 8.4875,
    lng: 123.8050,
  ),
  OroquietaSchool(
    id: 'oais-oroquieta',
    name: 'Oroquieta Agro-Industrial School (OAIS / TESDA)',
    shortName: 'OAIS / TESDA',
    barangay: 'Villaflor',
    defaultAddress: 'Purok 1, Brgy. Villaflor, Oroquieta City',
    lat: 8.4950,
    lng: 123.7980,
  ),
  OroquietaSchool(
    id: 'smc-oroquieta',
    name: 'Stella Maris College (SMC) - Oroquieta City',
    shortName: 'Stella Maris College',
    barangay: 'Poblacion',
    defaultAddress: 'Burgos St., Brgy. Poblacion, Oroquieta City',
    lat: 8.4860,
    lng: 123.8065,
  ),
  OroquietaSchool(
    id: 'monhs-oroquieta',
    name: 'Misamis Occidental National High School (MONHS)',
    shortName: 'MONHS',
    barangay: 'Poblacion 1',
    defaultAddress: 'Capitol Drive, Brgy. Poblacion 1, Oroquieta City',
    lat: 8.4868,
    lng: 123.8052,
  ),
  OroquietaSchool(
    id: 'ocnhs-oroquieta',
    name: 'Oroquieta City National High School (OCNHS)',
    shortName: 'Oroquieta City NHS',
    barangay: 'Mobod',
    defaultAddress: 'National Highway, Brgy. Mobod, Oroquieta City',
    lat: 8.4910,
    lng: 123.8025,
  ),
  OroquietaSchool(
    id: 'mobod-is',
    name: 'Mobod Integrated School',
    shortName: 'Mobod Integrated School',
    barangay: 'Mobod',
    defaultAddress: 'Purok 4, Brgy. Mobod, Oroquieta City',
    lat: 8.4902,
    lng: 123.8042,
  ),
  OroquietaSchool(
    id: 'talic-nhs',
    name: 'Talic National High School',
    shortName: 'Talic NHS',
    barangay: 'Talic',
    defaultAddress: 'Purok 2, Brgy. Talic, Oroquieta City',
    lat: 8.4920,
    lng: 123.8005,
  ),
  OroquietaSchool(
    id: 'rizal-nhs',
    name: 'Rizal National High School (Oroquieta)',
    shortName: 'Rizal NHS',
    barangay: 'Rizal',
    defaultAddress: 'Brgy. Rizal, Oroquieta City',
    lat: 8.4775,
    lng: 123.7960,
  ),
  OroquietaSchool(
    id: 'bunga-nhs',
    name: 'Bunga National High School (Oroquieta)',
    shortName: 'Bunga NHS',
    barangay: 'Bunga',
    defaultAddress: 'Brgy. Bunga, Oroquieta City',
    lat: 8.4720,
    lng: 123.7920,
  ),
  OroquietaSchool(
    id: 'senote-nhs',
    name: 'Senote National High School (Oroquieta)',
    shortName: 'Senote NHS',
    barangay: 'Senote',
    defaultAddress: 'Brgy. Senote, Oroquieta City',
    lat: 8.4820,
    lng: 123.7880,
  ),
];
