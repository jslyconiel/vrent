import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'firebase_service.dart';

class NotificationService {
  NotificationService._();
  static final NotificationService instance = NotificationService._();

  final FlutterLocalNotificationsPlugin _localPlugin = FlutterLocalNotificationsPlugin();
  bool _initialized = false;

  Future<void> init(FirebaseService firebaseService) async {
    if (_initialized || kIsWeb) return;
    try {
      const androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
      await _localPlugin.initialize(const InitializationSettings(android: androidSettings));

      final messaging = FirebaseMessaging.instance;
      await messaging.requestPermission(alert: true, badge: true, sound: true);
      await messaging.subscribeToTopic('oroquieta_announcements');

      final token = await messaging.getToken();
      final uid = firebaseService.currentFirebaseUser?.uid;
      if (token != null && uid != null) {
        await firebaseService.saveUserFcmToken(uid, token);
      }

      FirebaseMessaging.onMessage.listen((RemoteMessage message) {
        final notif = message.notification;
        if (notif == null) return;
        _localPlugin.show(
          notif.hashCode,
          notif.title ?? 'VRENT Oroquieta',
          notif.body ?? '',
          const NotificationDetails(
            android: AndroidNotificationDetails(
              'vrent_channel',
              'VRENT Boarding Updates',
              importance: Importance.high,
              priority: Priority.high,
            ),
          ),
        );
      });

      _initialized = true;
    } catch (_) {
      // Safe fallback when Firebase Messaging is not yet configured locally
    }
  }

  Future<void> syncTokenForUser(FirebaseService firebaseService, String uid) async {
    if (kIsWeb) return;
    try {
      final token = await FirebaseMessaging.instance.getToken();
      if (token != null) {
        await firebaseService.saveUserFcmToken(uid, token);
      }
    } catch (_) {}
  }
}
