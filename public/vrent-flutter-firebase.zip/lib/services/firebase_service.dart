import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/foundation.dart';
import 'package:video_compress/video_compress.dart';
import '../data/oroquieta_seed.dart';
import '../models/room.dart';

class FirebaseService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final FirebaseStorage _storage = FirebaseStorage.instance;

  static const int maxVideoBytes = 50 * 1024 * 1024; // 50 MB
  static const int maxVideoSeconds = 90;

  User? get currentFirebaseUser => _auth.currentUser;

  /// Ensures Sunrise Student Haven & initial notice exist in Firestore on first launch.
  Future<void> seedInitialRoomIfEmpty() async {
    final snapshot = await _db.collection('rooms').limit(1).get();
    if (snapshot.docs.isEmpty) {
      await _db
          .collection('rooms')
          .doc(sunriseStudentHavenSeed.id)
          .set(sunriseStudentHavenSeed.toMap());
    }
  }

  Future<void> saveUserFcmToken(String uid, String token) async {
    await _db.collection('users').doc(uid).set(
      {'fcmToken': token},
      SetOptions(merge: true),
    );
  }

  /// Sign in (email & password) or create a new verified student/owner account.
  Future<AppUser> signInOrRegister({
    required String email,
    required String password,
    required String role,
    required bool isSignUp,
    String? fullName,
    int? age,
    String? gender,
    String? school,
    String? ownerIdType,
  }) async {
    UserCredential cred;
    if (isSignUp) {
      cred = await _auth.createUserWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );
      final name = (fullName != null && fullName.trim().isNotEmpty)
          ? fullName.trim()
          : email.split('@').first;
      await cred.user!.updateDisplayName(name);
      await _db.collection('users').doc(cred.user!.uid).set({
        'name': name,
        'email': email.trim(),
        'role': role,
        if (age != null) 'age': age,
        if (gender != null) 'gender': gender,
        if (school != null) 'school': school,
        if (ownerIdType != null) 'ownerIdType': ownerIdType,
        'createdAt': DateTime.now().toIso8601String(),
      });
      return AppUser(
        uid: cred.user!.uid,
        name: name,
        email: email.trim(),
        role: role,
        age: age,
        gender: gender,
        school: school,
        ownerIdType: ownerIdType,
      );
    } else {
      cred = await _auth.signInWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );
      final userDoc = await _db.collection('users').doc(cred.user!.uid).get();
      final data = userDoc.data() ?? {};
      final resolvedName =
          (data['name'] ?? cred.user!.displayName ?? email.split('@').first) as String;
      return AppUser(
        uid: cred.user!.uid,
        name: resolvedName,
        email: email.trim(),
        role: (data['role'] ?? role) as String,
        age: (data['age'] as num?)?.toInt(),
        gender: data['gender'] as String?,
        school: data['school'] as String?,
        studentIdPhotoUrl: data['studentIdPhotoUrl'] as String?,
        ownerIdType: data['ownerIdType'] as String?,
        ownerVerificationDocUrl: data['ownerVerificationDocUrl'] as String?,
      );
    }
  }

  Future<void> saveUserStudentIdUrl(String uid, String url) async {
    await _db.collection('users').doc(uid).set(
      {'studentIdPhotoUrl': url},
      SetOptions(merge: true),
    );
  }

  Future<void> saveOwnerVerificationUrl(String uid, String idType, String url) async {
    await _db.collection('users').doc(uid).set(
      {'ownerIdType': idType, 'ownerVerificationDocUrl': url},
      SetOptions(merge: true),
    );
  }

  Future<void> signOut() => _auth.signOut();


  Stream<List<Room>> watchOwnerRooms(String ownerId) {
    return _db
        .collection('rooms')
        .where('ownerId', isEqualTo: ownerId)
        .snapshots()
        .map((snap) => snap.docs
            .map((doc) => Room.fromMap(doc.id, doc.data()))
            .toList());
  }

  Stream<List<BookingRequest>> watchOwnerBookingRequests(String ownerId) {
    return _db
        .collection('booking_requests')
        .where('ownerId', isEqualTo: ownerId)
        .snapshots()
        .map((snap) {
          final list = snap.docs
              .map((doc) => BookingRequest.fromMap(doc.id, doc.data()))
              .toList();
          list.sort((a, b) => b.createdAt.compareTo(a.createdAt));
          return list;
        });
  }

  Stream<List<PaymentRecord>> watchOwnerPayments(String ownerId) {
    return _db
        .collection('payments')
        .where('ownerId', isEqualTo: ownerId)
        .snapshots()
        .map((snap) {
          final list = snap.docs
              .map((doc) => PaymentRecord.fromMap(doc.id, doc.data()))
              .toList();
          list.sort((a, b) => b.paidDate.compareTo(a.paidDate));
          return list;
        });
  }

  Stream<List<OwnerAnnouncement>> watchOwnerAnnouncements(String ownerId) {
    return _db
        .collection('announcements')
        .where('ownerId', isEqualTo: ownerId)
        .snapshots()
        .map((snap) {
          final list = snap.docs
              .map((doc) => OwnerAnnouncement.fromMap(doc.id, doc.data()))
              .toList();
          list.sort((a, b) => b.date.compareTo(a.date));
          return list;
        });
  }

  Stream<List<Room>> watchOroquietaRooms() {
    return _db
        .collection('rooms')
        .where('city', isEqualTo: 'Oroquieta')
        .snapshots()
        .map((snap) => snap.docs
            .map((doc) => Room.fromMap(doc.id, doc.data()))
            .toList());
  }

  Future<void> addRoom(Room room) async {
    await _db.collection('rooms').doc(room.id).set(room.toMap());
  }

  Future<void> updateRoom(Room room) async {
    await _db.collection('rooms').doc(room.id).update(room.toMap());
  }

  Future<void> deleteRoom(String roomId) async {
    await _db.collection('rooms').doc(roomId).delete();
  }

  /// Validates video duration/size and compresses mobile footage cleanly before upload.
  Future<Uint8List> prepareVideoBytesForUpload(String path) async {
    final file = File(path);
    final rawSize = await file.length();
    if (!kIsWeb) {
      try {
        final info = await VideoCompress.getMediaInfo(path);
        final durationSec = ((info.duration ?? 0) / 1000).round();
        if (durationSec > maxVideoSeconds) {
          throw Exception('Video is ${durationSec}s long. Max allowed is ${maxVideoSeconds}s.');
        }
        if (rawSize > 12 * 1024 * 1024) {
          final compressed = await VideoCompress.compressVideo(
            path,
            quality: VideoQuality.MediumQuality,
            deleteOrigin: false,
          );
          if (compressed?.file != null) {
            final compSize = await compressed!.file!.length();
            if (compSize > maxVideoBytes) {
              throw Exception('Compressed video still exceeds 50 MB limit.');
            }
            return compressed.file!.readAsBytes();
          }
        }
      } catch (e) {
        if (e.toString().contains('Max allowed') || e.toString().contains('50 MB')) {
          rethrow;
        }
      }
    }
    if (rawSize > maxVideoBytes) {
      throw Exception('Video exceeds 50 MB limit. Please record a shorter tour.');
    }
    return file.readAsBytes();
  }

  /// Upload video or 360 panorama to Firebase Storage and return RoomMedia.
  Future<RoomMedia> uploadRoomMediaFile({
    required String roomId,
    required String type,
    required Uint8List bytes,
    required String fileName,
    String? caption,
  }) async {
    final ext = fileName.contains('.')
        ? fileName.split('.').last
        : (type == 'video' ? 'mp4' : 'jpg');
    final ref = _storage.ref('room_media/$roomId/${DateTime.now().millisecondsSinceEpoch}.$ext');
    final metadata = SettableMetadata(
      contentType: type == 'video' ? 'video/$ext' : 'image/$ext',
    );
    await ref.putData(bytes, metadata);
    final url = await ref.getDownloadURL();
    return RoomMedia(
      type: type,
      url: url,
      fileName: fileName,
      caption: caption?.trim().isNotEmpty == true
          ? caption!.trim()
          : (type == 'video' ? 'Owner Room Walkthrough Video' : 'Owner 360° Room Panorama'),
      uploadedAt: DateTime.now().toIso8601String(),
    );
  }

  /// Upload image (Student ID / GCash Receipt / Barangay Permit) to Firebase Storage.
  Future<String> uploadImageBytes({
    required String folder,
    required Uint8List bytes,
    required String fileName,
  }) async {
    final ext = fileName.contains('.') ? fileName.split('.').last : 'jpg';
    final ref = _storage.ref('$folder/${DateTime.now().millisecondsSinceEpoch}.$ext');
    await ref.putData(bytes, SettableMetadata(contentType: 'image/$ext'));
    return ref.getDownloadURL();
  }

  Future<void> attachRoomMedia(String roomId, RoomMedia media) async {
    await _db.collection('rooms').doc(roomId).update({'roomMedia': media.toMap()});
  }

  Future<void> saveOwnerVerificationDoc(String roomId, String idType, String docUrl) async {
    await _db.collection('rooms').doc(roomId).update({
      'ownerIdType': idType,
      'ownerVerificationDocUrl': docUrl,
      'ownerVerified': true,
    });
  }

  Stream<List<BookingRequest>> watchBookingRequests() {
    return _db
        .collection('booking_requests')
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snap) => snap.docs
            .map((doc) => BookingRequest.fromMap(doc.id, doc.data()))
            .toList());
  }

  Future<void> submitBookingRequest(BookingRequest request) async {
    await _db.collection('booking_requests').add(request.toMap());
  }

  /// Atomic Firestore Transaction: Approves request, decrements slotsAvailable,
  /// and marks the matching sub-unit as occupied.
  Future<void> approveBookingAndSyncSlot(BookingRequest req) async {
    final reqRef = _db.collection('booking_requests').doc(req.id);
    final roomRef = _db.collection('rooms').doc(req.roomId);

    await _db.runTransaction((tx) async {
      final reqSnap = await tx.get(reqRef);
      if (!reqSnap.exists) return;
      final currentStatus = (reqSnap.data()?['status'] ?? 'pending') as String;
      if (currentStatus == 'approved') return;

      tx.update(reqRef, {'status': 'approved'});

      final roomSnap = await tx.get(roomRef);
      if (!roomSnap.exists) return;
      final roomData = roomSnap.data()!;
      final currentSlots = ((roomData['slotsAvailable'] ?? 0) as num).toInt();
      final nextSlots = currentSlots > 0 ? currentSlots - 1 : 0;

      final rawSubUnits = List<Map<String, dynamic>>.from(
        (roomData['subUnits'] as List<dynamic>? ?? [])
            .map((e) => Map<String, dynamic>.from(e as Map)),
      );

      bool assignedOne = false;
      final nextSubUnits = rawSubUnits.map((unit) {
        if (assignedOne) return unit;
        final unitNum = (unit['unitNumber'] ?? '') as String;
        final unitStatus = (unit['status'] ?? 'available') as String;
        final exactMatch = req.unitNumber != null &&
            unitNum.toLowerCase() == req.unitNumber!.toLowerCase();
        final fallbackAvail = req.unitNumber == null && unitStatus == 'available';
        if (exactMatch || fallbackAvail) {
          assignedOne = true;
          return {
            ...unit,
            'status': 'occupied',
            'currentTenant': req.renterName,
          };
        }
        return unit;
      }).toList();

      tx.update(roomRef, {
        'slotsAvailable': nextSlots,
        'subUnits': nextSubUnits,
      });
    });
  }

  Future<void> declineBookingRequest(String requestId) async {
    await _db.collection('booking_requests').doc(requestId).update({'status': 'declined'});
  }

  Stream<List<PaymentRecord>> watchPayments() {
    return _db
        .collection('payments')
        .orderBy('paidDate', descending: true)
        .snapshots()
        .map((snap) => snap.docs
            .map((doc) => PaymentRecord.fromMap(doc.id, doc.data()))
            .toList());
  }

  Future<void> submitPayment(PaymentRecord payment) async {
    await _db.collection('payments').add(payment.toMap());
  }

  Future<void> verifyPayment(String paymentId) async {
    await _db.collection('payments').doc(paymentId).update({'status': 'confirmed'});
  }

  Stream<List<OwnerAnnouncement>> watchAnnouncements() {
    return _db
        .collection('announcements')
        .orderBy('date', descending: true)
        .snapshots()
        .map((snap) => snap.docs
            .map((doc) => OwnerAnnouncement.fromMap(doc.id, doc.data()))
            .toList());
  }

  Future<void> postAnnouncement(OwnerAnnouncement announcement) async {
    await _db.collection('announcements').add(announcement.toMap());
  }

  Stream<List<ChatMessage>> watchRoomChat(String roomId) {
    return _db
        .collection('chats')
        .doc(roomId)
        .collection('messages')
        .orderBy('createdAt')
        .snapshots()
        .map((snap) => snap.docs
            .map((doc) => ChatMessage.fromMap(doc.id, doc.data()))
            .toList());
  }

  Future<void> sendChatMessage(String roomId, ChatMessage message) async {
    await _db
        .collection('chats')
        .doc(roomId)
        .collection('messages')
        .add(message.toMap());
  }

  Future<Uint8List> readFileBytes(String path) => File(path).readAsBytes();
}
