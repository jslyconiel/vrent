import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'firebase_options.dart';
import 'models/room.dart';
import 'screens/intro_screen.dart';
import 'screens/search_screen.dart';
import 'screens/auth_screen.dart';
import 'screens/owner_dashboard_screen.dart';
import 'services/firebase_service.dart';
import 'services/notification_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const VrentApp());
}

class VrentApp extends StatefulWidget {
  const VrentApp({super.key});

  @override
  State<VrentApp> createState() => _VrentAppState();
}

class _VrentAppState extends State<VrentApp> {
  final FirebaseService _firebaseService = FirebaseService();
  AppUser? _currentUser;
  DateTime _sessionStart = DateTime.now();

  @override
  void initState() {
    super.initState();
    NotificationService.instance.init(_firebaseService);
  }

  @override
  Widget build(BuildContext context) {
    final baseTextTheme = GoogleFonts.plusJakartaSansTextTheme().copyWith(
      bodyLarge: GoogleFonts.plusJakartaSans(fontSize: 18, height: 1.5),
      bodyMedium: GoogleFonts.plusJakartaSans(fontSize: 16, height: 1.5),
      bodySmall: GoogleFonts.plusJakartaSans(fontSize: 14, height: 1.4),
      titleLarge: GoogleFonts.fraunces(fontSize: 26, fontWeight: FontWeight.w800),
      titleMedium: GoogleFonts.plusJakartaSans(fontSize: 20, fontWeight: FontWeight.w700),
    );

    return MaterialApp(
      title: 'VRENT — Oroquieta City Boarding Houses',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFE05D26),
          primary: const Color(0xFFE05D26),
          surface: const Color(0xFFFAF7F2),
        ),
        scaffoldBackgroundColor: const Color(0xFFFAF7F2),
        textTheme: baseTextTheme,
      ),
      home: Builder(
        builder: (navContext) {
          return IntroScreen(
            onExploreRooms: () {
              Navigator.of(navContext).push(
                MaterialPageRoute(
                  builder: (_) => SearchScreen(
                    firebaseService: _firebaseService,
                    currentUser: _currentUser,
                    sessionStart: _sessionStart,
                    onOpenAuth: (mode) => _openAuth(navContext, mode),
                    onLogout: () => _handleLogout(navContext, _currentUser?.role ?? 'renter'),
                  ),
                ),
              );
            },
            onOpenAuth: (mode) => _openAuth(navContext, mode),
          );
        },
      ),
    );
  }

  Future<void> _handleLogout(BuildContext context, String role) async {
    await _firebaseService.signOut();
    setState(() {
      _currentUser = null;
      _sessionStart = DateTime.now();
    });
    if (!context.mounted) return;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (authCtx) => AuthScreen(
          firebaseService: _firebaseService,
          initialRole: role,
          onAuthenticated: (user) => _handleAuthenticated(authCtx, user),
        ),
      ),
    );
  }

  void _openAuth(BuildContext context, String initialRole) {
    if (initialRole == 'owner' && _currentUser?.role == 'owner') {
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (dashCtx) => OwnerDashboardScreen(
            firebaseService: _firebaseService,
            ownerUser: _currentUser!,
            onLogout: () => _handleLogout(dashCtx, 'owner'),
          ),
        ),
      );
      return;
    }

    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (authCtx) => AuthScreen(
          firebaseService: _firebaseService,
          initialRole: initialRole,
          onAuthenticated: (user) => _handleAuthenticated(authCtx, user),
        ),
      ),
    );
  }

  void _handleAuthenticated(BuildContext context, AppUser user) {
    setState(() {
      _currentUser = user;
      _sessionStart = DateTime.now();
    });
    NotificationService.instance.syncTokenForUser(_firebaseService, user.uid);
    if (user.role == 'owner') {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (dashCtx) => OwnerDashboardScreen(
            firebaseService: _firebaseService,
            ownerUser: user,
            onLogout: () => _handleLogout(dashCtx, 'owner'),
          ),
        ),
      );
    } else {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (searchCtx) => SearchScreen(
            firebaseService: _firebaseService,
            currentUser: user,
            sessionStart: _sessionStart,
            onOpenAuth: (mode) => _openAuth(searchCtx, mode),
            onLogout: () => _handleLogout(searchCtx, 'renter'),
          ),
        ),
      );
    }
  }
}
