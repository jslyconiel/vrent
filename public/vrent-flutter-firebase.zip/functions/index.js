const { onDocumentCreated, onDocumentUpdated } = require("firebase-functions/v2/firestore");
const admin = require("firebase-admin");

admin.initializeApp();

exports.onBookingCreated = onDocumentCreated("booking_requests/{requestId}", async (event) => {
  const data = event.data?.data();
  if (!data) return;
  const ownerDoc = await admin.firestore().collection("users").doc(data.ownerId).get();
  const fcmToken = ownerDoc.data()?.fcmToken;
  if (!fcmToken) return;
  await admin.messaging().send({
    token: fcmToken,
    notification: {
      title: "New VRENT Booking Request",
      body: `${data.renterName} applied for ${data.roomTitle}${data.unitNumber ? ` (${data.unitNumber})` : ""}.`,
    },
  });
});

exports.onBookingUpdated = onDocumentUpdated("booking_requests/{requestId}", async (event) => {
  const before = event.data?.before.data();
  const after = event.data?.after.data();
  if (!before || !after || before.status === after.status) return;
  const renterDoc = await admin.firestore().collection("users").doc(after.renterId).get();
  const fcmToken = renterDoc.data()?.fcmToken;
  if (!fcmToken) return;
  await admin.messaging().send({
    token: fcmToken,
    notification: {
      title: `Booking ${after.status.toUpperCase()}`,
      body: `Your reservation at ${after.roomTitle} was ${after.status}.`,
    },
  });
});

exports.onAnnouncementCreated = onDocumentCreated("announcements/{annId}", async (event) => {
  const data = event.data?.data();
  if (!data) return;
  await admin.messaging().send({
    topic: "oroquieta_announcements",
    notification: {
      title: `Notice: ${data.title}`,
      body: data.message,
    },
  });
});

exports.onChatMessageCreated = onDocumentCreated("chats/{roomId}/messages/{msgId}", async (event) => {
  const data = event.data?.data();
  if (!data) return;
  await admin.messaging().send({
    topic: `chat_${event.params.roomId}`,
    notification: {
      title: `Message from ${data.senderName}`,
      body: data.text,
    },
  });
});
