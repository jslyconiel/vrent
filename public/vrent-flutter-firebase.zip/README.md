# VRENT — Oroquieta City (Flutter + Firebase + APK)

Complete Android & Web Flutter project backed by Firebase Auth, Cloud Firestore, Firebase Storage, FCM Push Notifications, and Cloud Functions.

## Quick Setup in VS Code
1. Install Flutter SDK and Firebase CLI + FlutterFire CLI:
   ```bash
   dart pub global activate flutterfire_cli
   flutterfire configure
   ```
2. Deploy Firestore & Storage rules + Push Notification Cloud Functions:
   ```bash
   firebase deploy --only firestore:rules,storage
   cd functions && npm install && cd .. && firebase deploy --only functions
   ```
3. Build Android APK locally or via GitHub Actions (`.github/workflows/build_apk.yml`):
   ```bash
   flutter create --platforms=android .
   flutter pub get
   flutter build apk --release
   ```
